package cs3500.marblesolitaire.model.hw02;

import java.util.ArrayList;

import cs3500.marblesolitaire.model.hw04.ASolitaireModel;

/**
 * Represent a game of English Solitaire, a variant of Marble solitaire with a '+' shaped board.
 */
public class EnglishSolitaireModel extends ASolitaireModel {

  /**
   * Calculate and return the board size (roughly the longest dimension of the board).
   *     @return the board size, as an int.
   */
  @Override
  public int getBoardSize() {
    return 3 * super.dimensions - 2;
  }

  protected SlotState grab(int row, int col) {
    return this.grid.get(row).get(col);
  }

  /**
   * Default Constructor - create a new EnglishSolitaireModel
   * with armThickness 3 and empty slot in the center.
   */
  public EnglishSolitaireModel() {
    super(3, 3, 3);
  }

  /**
   * Second Constructor - create a new EnglishSolitaireModel
   * with armThickness 3 and empty slot at the specified coordinates.
   *     @param sRow the target row for the empty slot.
   *     @param sCol the target column for the empty slot.
   *     @throws IllegalArgumentException if the target position for the empty slot isn't valid.
   */
  public EnglishSolitaireModel(int sRow, int sCol) throws IllegalArgumentException {
    super(3, sRow, sCol);
  }

  /**
   * Third Constructor - create a new EnglishSolitaireModel
   * with given armThickness and empty slot in the middle.
   *     @param armThickness the armThickness for the EnglishSolitaireModel (must be > 2 and odd).
   *     @throws IllegalArgumentException if the armThickness is not > 2 and odd.
   */
  public EnglishSolitaireModel(int armThickness) throws IllegalArgumentException {
    super(armThickness,  armThickness + (armThickness / 2) - 1,
            armThickness + (armThickness / 2) - 1);
  }

  /**
   * Fourth Constructor - create a new EnglishSolitaireModel
   * with given armThickness and empty slot at the specified coordinates.
   *     @param armThickness the armThickness for the EnglishSolitaireModel
   *     @param row the row position for the empty slot.
   *     @param col the column position for the empty slot.
   *     @throws IllegalArgumentException if either the armThickness is un-allowable or the
   *     specified coordinates for the empty slot are out-of bounds.
   */
  public EnglishSolitaireModel(int armThickness, int row, int col) throws IllegalArgumentException {
    super(armThickness, row, col);
  }

  /**
   * Is the given armThickness acceptable?. If so, return true.
   *     @param armThickness the potential armThickness for the EnglishSolitaireModel.
   *     @return true if the armThickness is valid, false otherwise.
   */
  @Override
  protected boolean sizeOk(int armThickness) {
    return armThickness > 2 && armThickness % 2 == 1;
  }

  /**
   * Will the given coordinates result in a valid position on the board? If so, return true.
   *     @param row the target row position.
   *     @param col the target column position.
   *     @return true if the specified coordinates are valid, false otherwise.
   */
  protected boolean isPositionOk(int row, int col) {
    int size = this.getBoardSize();
    int armThickness = super.dimensions;
    return row >= 0 && col >= 0 && row < size && col < size
            && !((col < armThickness - 1 || col >= (2 * armThickness) - 1)
            && (row < armThickness - 1 || row >= (2 * armThickness) - 1));
  }

  /**
   * Set up the board by initializing all SlotStates to their proper values based on
   * the given armThickness and empty slot coordinates. Relies on having valid inputs.
   *     @param armThickness the armThickness for the EnglishSolitaireModel.
   *     @param row the row position of the empty slot.
   *     @param col the column position of the empty slot.
   */
  protected void generateGrid(int armThickness, int row, int col) {
    int boardSize = this.getBoardSize();
    ArrayList<ArrayList<SlotState>> theList = new ArrayList<ArrayList<SlotState>>();
    for (int i = 0; i < boardSize; i = i + 1) {
      ArrayList<SlotState> theRow = new ArrayList<SlotState>();

      for (int j = 0; j < boardSize; j = j + 1) {
        SlotState temp;

        if ((j < armThickness - 1 || j >= (2 * armThickness) - 1) &&
                (i < armThickness - 1 || i >= (2 * armThickness) - 1)) {
          temp = SlotState.Invalid;
        } else if (i == row && j == col) {
          temp = SlotState.Empty;
        } else {
          temp = SlotState.Marble;
        }
        theRow.add(temp);
      }
      theList.add(theRow);
    }
    this.grid = theList;
  }

}