import org.junit.Test;

import java.io.IOException;
import java.io.StringReader;


import cs3500.marblesolitaire.controller.MarbleSolitaireController;
import cs3500.marblesolitaire.controller.MarbleSolitaireControllerImpl;
import cs3500.marblesolitaire.model.hw02.EnglishSolitaireModel;
import cs3500.marblesolitaire.model.hw02.MarbleSolitaireModel;

import cs3500.marblesolitaire.model.hw04.ASolitaireModel;
import cs3500.marblesolitaire.model.hw04.EuropeanSolitaireModel;
import cs3500.marblesolitaire.model.hw04.TriangleSolitaireModel;
import cs3500.marblesolitaire.view.ATextView;
import cs3500.marblesolitaire.view.MarbleSolitaireTextView;
import cs3500.marblesolitaire.view.MarbleSolitaireView;
import cs3500.marblesolitaire.view.TriangleSolitaireTextView;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;

/**
 * Test the controller by checking that it sends the proper inputs in all cases.
 */
public class TestController {

  MarbleSolitaireModel model;
  ASolitaireModel europe;
  ASolitaireModel tri;
  ATextView triview;
  RecordingView view;
  RecordingModel fmodel;
  MarbleSolitaireView tview;
  MarbleSolitaireController controller;

  /**
   * setup the testing objects.
   *     @param s the starting string for the reader.
   */
  public void setup(String s) {
    model = new EnglishSolitaireModel();
    fmodel = new RecordingModel(new StringBuilder(""), model);
    tview = new MarbleSolitaireTextView(model);
    view = new RecordingView(new StringBuilder(""), tview); //change to fakes?
    controller = new MarbleSolitaireControllerImpl(fmodel, view, new StringReader(s));
    tri = new TriangleSolitaireModel();
    europe = new EuropeanSolitaireModel();
    triview = new TriangleSolitaireTextView(tri);
  }

  @Test
  public void testControllerConstructorGood() {
    MarbleSolitaireModel test = new EnglishSolitaireModel();
    MarbleSolitaireView view = new MarbleSolitaireTextView(test);
    MarbleSolitaireController controller = new MarbleSolitaireControllerImpl(test, view,
            new StringReader(""));

    assertTrue(controller != null);

  }

  @Test(expected = IllegalArgumentException.class)
  public void testControllerConstructorBad() {
    MarbleSolitaireModel test = new EnglishSolitaireModel();
    MarbleSolitaireView view = new MarbleSolitaireTextView(test);
    MarbleSolitaireController controller = new MarbleSolitaireControllerImpl(null, view,
            new StringReader(""));

  }

  @Test(expected = IllegalArgumentException.class)
  public void testControllerConstructorBad2() {
    MarbleSolitaireModel test = new EnglishSolitaireModel();
    MarbleSolitaireView view = new MarbleSolitaireTextView(test);
    MarbleSolitaireController controller = new MarbleSolitaireControllerImpl(test, null,
            new StringReader(""));

  }

  @Test(expected = IllegalArgumentException.class)
  public void testControllerConstructorBad3() {
    MarbleSolitaireModel test = new EnglishSolitaireModel();
    MarbleSolitaireView view = new MarbleSolitaireTextView(test);
    MarbleSolitaireController controller = new MarbleSolitaireControllerImpl(test, view,
            null);

  }

  @Test
  public void testPlayGameQuit() {
    setup("q");
    String old = view.toString();
    controller.playGame();
    assertEquals(view.toString(), old); //no change in model, since we know view works correctly.
    assertEquals(view.getLog(), "    O O O\n" +
            "    O O O\n" +
            "O O O O O O O\n" +
            "O O O _ O O O\n" +
            "O O O O O O O\n" +
            "    O O O\n" +
            "    O O O\n" +
            "Score: 32\n" +
            "Game quit!\n" +
            "State of game when quit:\n" +
            "    O O O\n" +
            "    O O O\n" +
            "O O O O O O O\n" +
            "O O O _ O O O\n" +
            "O O O O O O O\n" +
            "    O O O\n" +
            "    O O O\n" +
            "Score: 32\n"); //instant quit
  }

  @Test
  public void testPlayGameQuit2() {
    setup("1 2 q");
    String old = view.toString();
    controller.playGame();
    assertEquals(view.toString(), old); //no change in model, since we know view works correctly.
    assertEquals(view.getLog(), "    O O O\n" +
            "    O O O\n" +
            "O O O O O O O\n" +
            "O O O _ O O O\n" +
            "O O O O O O O\n" +
            "    O O O\n" +
            "    O O O\n" +
            "Score: 32\n" +
            "Game quit!\n" +
            "State of game when quit:\n" +
            "    O O O\n" +
            "    O O O\n" +
            "O O O O O O O\n" +
            "O O O _ O O O\n" +
            "O O O O O O O\n" +
            "    O O O\n" +
            "    O O O\n" +
            "Score: 32\n"); //instant quit
  }

  @Test
  public void testPlayGameQuit3() {
    setup("1 2 3 q");
    String old = view.toString();
    controller.playGame();
    assertEquals(view.toString(), old); //no change in model, since we know view works correctly.
    assertEquals(view.getLog(), "    O O O\n" +
            "    O O O\n" +
            "O O O O O O O\n" +
            "O O O _ O O O\n" +
            "O O O O O O O\n" +
            "    O O O\n" +
            "    O O O\n" +
            "Score: 32\n" +
            "Game quit!\n" +
            "State of game when quit:\n" +
            "    O O O\n" +
            "    O O O\n" +
            "O O O O O O O\n" +
            "O O O _ O O O\n" +
            "O O O O O O O\n" +
            "    O O O\n" +
            "    O O O\n" +
            "Score: 32\n"); //instant quit
  }

  @Test
  public void testPlayGameQuitAfterGood() {
    setup("2 4 4 4 q");
    String old = view.toString();
    controller.playGame();
    assertFalse(old.equals(view.toString()));
    assertEquals(fmodel.getLog(), "Move: 1 3 3 3"); //ensure move passed properly
    assertEquals(view.getLog(), "    O O O\n" +
            "    O O O\n" +
            "O O O O O O O\n" +
            "O O O _ O O O\n" +
            "O O O O O O O\n" +
            "    O O O\n" +
            "    O O O\n" +
            "Score: 32\n" +
            "    O O O\n" +
            "    O _ O\n" +
            "O O O _ O O O\n" +
            "O O O O O O O\n" +
            "O O O O O O O\n" +
            "    O O O\n" +
            "    O O O\n" +
            "Score: 31\n" +
            "Game quit!\n" +
            "State of game when quit:\n" +
            "    O O O\n" +
            "    O _ O\n" +
            "O O O _ O O O\n" +
            "O O O O O O O\n" +
            "O O O O O O O\n" +
            "    O O O\n" +
            "    O O O\n" +
            "Score: 31\n");
  }

  @Test
  public void testPlayGameWithEurope() {
    setup("2 4 4 4 q");
    MarbleSolitaireView euview = new MarbleSolitaireTextView(europe);
    RecordingView review = new RecordingView(new StringBuilder(""), euview);
    RecordingModel fmodel = new RecordingModel(new StringBuilder(""), europe);
    controller = new MarbleSolitaireControllerImpl(fmodel, review, new StringReader("2 4 4 4 q"));
    String old = review.toString();
    controller.playGame();
    assertFalse(old.equals(review.toString()));
    assertEquals(fmodel.getLog(), "Move: 1 3 3 3"); //ensure move passed properly
    assertEquals(review.getLog(), "    O O O\n" +
            "  O O O O O\n" +
            "O O O O O O O\n" +
            "O O O _ O O O\n" +
            "O O O O O O O\n" +
            "  O O O O O\n" +
            "    O O O\n" +
            "Score: 36\n" +
            "    O O O\n" +
            "  O O _ O O\n" +
            "O O O _ O O O\n" +
            "O O O O O O O\n" +
            "O O O O O O O\n" +
            "  O O O O O\n" +
            "    O O O\n" +
            "Score: 35\n" +
            "Game quit!\n" +
            "State of game when quit:\n" +
            "    O O O\n" +
            "  O O _ O O\n" +
            "O O O _ O O O\n" +
            "O O O O O O O\n" +
            "O O O O O O O\n" +
            "  O O O O O\n" +
            "    O O O\n" +
            "Score: 35\n");
  }

  @Test
  public void testPlayGameWithTriangle() {
    setup("2 0 0 0 q");
    MarbleSolitaireView triview = new TriangleSolitaireTextView(tri);
    RecordingView review = new RecordingView(new StringBuilder(""), triview);
    RecordingModel fmodel = new RecordingModel(new StringBuilder(""), tri);
    controller = new MarbleSolitaireControllerImpl(fmodel, review, new StringReader("3 1 1 1 q"));
    String old = review.toString();
    controller.playGame();
    assertFalse(old.equals(review.toString()));
    assertEquals(fmodel.getLog(), "Move: 2 0 0 0"); //ensure move passed properly
    assertEquals(review.getLog(), "    _\n" +
            "   O O\n" +
            "  O O O\n" +
            " O O O O\n" +
            "O O O O O\n" +
            "Score: 14\n" +
            "    O\n" +
            "   _ O\n" +
            "  _ O O\n" +
            " O O O O\n" +
            "O O O O O\n" +
            "Score: 13\n" +
            "Game quit!\n" +
            "State of game when quit:\n" +
            "    O\n" +
            "   _ O\n" +
            "  _ O O\n" +
            " O O O O\n" +
            "O O O O O\n" +
            "Score: 13\n");
  }

  @Test
  public void testPlayGameQuitAfterBad() {
    setup("2 3 1 1 q");
    String old = view.toString();
    controller.playGame();
    assertEquals(view.toString(), old); //no change in model, since we know view works correctly.
    assertEquals(view.getLog(), "    O O O\n" +
            "    O O O\n" +
            "O O O O O O O\n" +
            "O O O _ O O O\n" +
            "O O O O O O O\n" +
            "    O O O\n" +
            "    O O O\n" +
            "Score: 32\n" +
            "Invalid move. Play again. :)\n" +
            "    O O O\n" +
            "    O O O\n" +
            "O O O O O O O\n" +
            "O O O _ O O O\n" +
            "O O O O O O O\n" +
            "    O O O\n" +
            "    O O O\n" +
            "Score: 32\n" +
            "Game quit!\n" +
            "State of game when quit:\n" +
            "    O O O\n" +
            "    O O O\n" +
            "O O O O O O O\n" +
            "O O O _ O O O\n" +
            "O O O O O O O\n" +
            "    O O O\n" +
            "    O O O\n" +
            "Score: 32\n");
  }

  @Test
  public void testPlayGameSecondaryInput() {
    setup("4 2 4 a 4 q");
    String old = view.toString();
    controller.playGame();
    assertFalse(old.equals(view.toString()));
  }

  @Test
  public void testPlayGameEnters() {
    setup("4 \n 2 \n 4 4 q");
    String old = view.toString();
    controller.playGame();
    assertFalse(old.equals(view.toString()));
  }

  @Test
  public void testPlayGameTabs() {
    setup("4  2 4 4 q");
    String old = view.toString();
    controller.playGame();
    assertFalse(old.equals(view.toString()));
  }

  @Test
  public void testEndAndALotOfMoves() {
    setup("4 6 4 4");
    model.move(5,3,3,3);
    model.move(4,5,4,3);
    model.move(6,4,4,4);
    model.move(6,2,6,4);
    model.move(3,4,5,4);
    model.move(6,4,4,4);
    model.move(1,4,3,4);
    model.move(2,6,2,4);
    model.move(4,6,2,6);
    model.move(2,3,2,5);
    model.move(2,6,2,4);
    model.move(2,1,2,3);
    model.move(0,2,2,2);
    model.move(0,4,0,2);
    model.move(3,2,1,2);
    model.move(0,2,2,2);
    model.move(5,2,3,2);
    model.move(4,0,4,2);
    model.move(2,0,4,0);
    model.move(4,3,4,1);
    model.move(4,0,4,2);
    model.move(2,3,2,1);
    model.move(2,1,4,1);
    model.move(4,1,4,3);
    model.move(4,3,4,5);
    model.move(4,5,2,5);
    model.move(2,5,2,3);
    model.move(3,3,3,5);
    model.move(1,3,3,3);
    model.move(3,2,3,4);
    controller.playGame();
    assertEquals(view.getLog(), "    _ _ _\n" +
            "    _ _ _\n" +
            "_ _ _ _ _ _ _\n" +
            "_ _ _ _ O O _\n" +
            "_ _ _ _ _ _ _\n" +
            "    _ _ _\n" +
            "    _ _ _\n" +
            "Score: 2\n" +
            "    _ _ _\n" +
            "    _ _ _\n" +
            "_ _ _ _ _ _ _\n" +
            "_ _ _ O _ _ _\n" +
            "_ _ _ _ _ _ _\n" +
            "    _ _ _\n" +
            "    _ _ _\n" +
            "Score: 1\n" +
            "Game over!\n" +
            "    _ _ _\n" +
            "    _ _ _\n" +
            "_ _ _ _ _ _ _\n" +
            "_ _ _ O _ _ _\n" +
            "_ _ _ _ _ _ _\n" +
            "    _ _ _\n" +
            "    _ _ _\n" +
            "Score: 1");
  }

  @Test
  public void testWonkyMoveGame() {
    setup("4 2 4 4 6 3 4 3 5 1 5 3 5 4 5 2 5 6 5 4 7 5 5 5 4 5 6 5 7 3 7 5 7 5 5 5 3 3 5 3" +
            " 1 3 3 3 2 5 4 a 5 4 5 6 5 6 5 6 3 6 3 4 3 4 3 2 3 3 1 5 1 5 1 5 3 5 3 5 5 3 7 3 " +
            "5 3 4 3 6 5 7 3 7 3 7 3 5 1 5 1 3 1 3 3 3 3 2 3 4 3 4 3 6 3 6 5 6 5 6" +
            " a 5 4 5 4 3 4 2 4 4 4");
    String old = view.toString();
    controller.playGame();
    assertFalse(old.equals(view.toString()));
  }

  @Test(expected = IllegalStateException.class)
  public void testRunOutOfInput() {
    setup("4 2 4 4 4 5 6");
    controller.playGame();
  }

  @Test(expected = IllegalStateException.class)
  public void testRunOutOfInputLetters() {
    setup("4 2 4 4 a 5 6");
    controller.playGame();
  }

  @Test
  public void testQuitBadLetters() {
    setup("4 2 4 a a 5 6 q");
    controller.playGame();
    assertEquals(view.getLog(), "    O O O\n" +
            "    O O O\n" +
            "O O O O O O O\n" +
            "O O O _ O O O\n" +
            "O O O O O O O\n" +
            "    O O O\n" +
            "    O O O\n" +
            "Score: 32\n" +
            "bad input, try again bad input, try again Invalid move. Play again. :)\n" +
            "    O O O\n" +
            "    O O O\n" +
            "O O O O O O O\n" +
            "O O O _ O O O\n" +
            "O O O O O O O\n" +
            "    O O O\n" +
            "    O O O\n" +
            "Score: 32\n" +
            "Game quit!\n" +
            "State of game when quit:\n" +
            "    O O O\n" +
            "    O O O\n" +
            "O O O O O O O\n" +
            "O O O _ O O O\n" +
            "O O O O O O O\n" +
            "    O O O\n" +
            "    O O O\n" +
            "Score: 32\n");
  }

  @Test
  public void testRenderBoard() {
    setup("");
    try {
      view.renderBoard();
      assertEquals(view.getLog(), "    O O O\n" +
              "    O O O\n" +
              "O O O O O O O\n" +
              "O O O _ O O O\n" +
              "O O O O O O O\n" +
              "    O O O\n" +
              "    O O O\n");
    } catch (IOException e) {
      fail();
    }
  }

  @Test
  public void testRenderMessage() {
    setup("");
    try {
      view.renderMessage("Hello. My name is Inigo Montoya.");
      assertEquals(view.getLog(), "Hello. My name is Inigo Montoya.");
    } catch (IOException e) {
      fail();
    }
  }

}
