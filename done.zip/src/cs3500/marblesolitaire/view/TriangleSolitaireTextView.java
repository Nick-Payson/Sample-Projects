package cs3500.marblesolitaire.view;

import cs3500.marblesolitaire.model.hw02.MarbleSolitaireModelState;
import cs3500.marblesolitaire.model.hw04.TriangleSolitaireModel;

/**
 * Display a TriangleSolitaireModel with text. Represent the state using spaces, O and _,
 * for invalid slots, marbles, and empty slots respectively.
 */
public class TriangleSolitaireTextView extends ATextView {

  /**
   * Constructor - make a new TriangleSolitaireTextView with the given model and appendable.
   *     @param state the board to represent.
   *     @param destination the Appendable to send outputs to.
   *     @throws IllegalArgumentException if inputs are invalid (null).
   */
  public TriangleSolitaireTextView(MarbleSolitaireModelState state, Appendable destination)
          throws IllegalArgumentException {

    super(state, destination);
    if (!(state instanceof TriangleSolitaireModel)) {
      throw new IllegalArgumentException("Passed a non-triangle model to triangle view");
    }
  }

  /**
   * Constructor - make a new TriangleSolitaireTextView with the given model.
   *     @param state the model to represent with this view.
   *     @throws IllegalArgumentException if the model is null.
   */
  public TriangleSolitaireTextView(MarbleSolitaireModelState state)
          throws IllegalArgumentException {

    super(state, System.out);
    if (!(state instanceof TriangleSolitaireModel)) {
      throw new IllegalArgumentException("Passed a non-triangle model to triangle view");
    }
  }

  /**
   * Return a string representing this model.
   *     @return the representation of this model, as a String.
   */
  public String toString() {
    String toReturn = "";
    int size = state.getBoardSize();

    for (int i = 0; i < size; i++) {
      String row = "";

      for (int k = 0; k < size - i - 1; k++) {
        row = row + " ";
      }

      for (int j = 0; j < i + 1; j++) {
        String addition = " ";
        if (state.getSlotAt(i, j) == MarbleSolitaireModelState.SlotState.Marble) {
          addition = "O" + addition;
        } else if (state.getSlotAt(i, j) == MarbleSolitaireModelState.SlotState.Invalid) {
          addition = " " + addition;
        } else {
          addition = "_" + addition;
        }
        row = row + addition;
      }
      row = this.truncateSpaces(row);
      toReturn = toReturn + row + "\n";
    }
    return toReturn.substring(0, toReturn.length() - 1);
  }
}
