package cs3500.marblesolitaire.view;

import cs3500.marblesolitaire.model.hw02.MarbleSolitaireModelState;

/**
 * Represent a MarbleSolitaireTextView, a type of MarbleSolitaireView that uses text-only output.
 */
public class MarbleSolitaireTextView extends ATextView {

  /**
   * Constructor - create a new MarbleSolitaireTextView with the given MarbleSolitaireModelState.
   *     @param state the MarbleSolitaireModelState for the View to display.
   *     @throws IllegalArgumentException if the provided MarbleSolitaireModelState is null.
   */
  public MarbleSolitaireTextView(MarbleSolitaireModelState state) throws IllegalArgumentException {
    super(state, System.out);
  }

  /**
   * Constructor - create a new MarbleSolitaireTextView with the given MarbleSolitaireModelState.
   *     @param state the MarbleSolitaireModelState for the View to display.
   *     @param destination the Appendable used for displays.
   *     @throws IllegalArgumentException if the provided MarbleSolitaireModelState is null,
   *     or if the provided Appendable is null.
   */
  public MarbleSolitaireTextView(MarbleSolitaireModelState state, Appendable destination)
          throws IllegalArgumentException {

    super(state, destination);
  }

  /**
   * This is the string to display, representing the MarbleSolitaireModelState in String format.
   *     @return this View's state, in String format.
   */
  public String toString() {
    String toReturn = "";
    int size = state.getBoardSize();
    for (int i = 0; i < size; i = i + 1) {
      String row = "";
      for (int j = 0; j < size; j = j + 1) {
        String addition = " ";
        if (state.getSlotAt(i, j) == MarbleSolitaireModelState.SlotState.Marble) {
          addition = "O" + addition;
        } else if (state.getSlotAt(i, j) == MarbleSolitaireModelState.SlotState.Invalid) {
          addition = " " + addition;
        } else {
          addition = "_" + addition;
        }
        row = row + addition;
      }

      row = this.truncateSpaces(row);
      toReturn = toReturn + row + "\n";
    }
    return toReturn.substring(0, toReturn.length() - 1); //get rid of last newline
  }



}
