package cs3500.marblesolitaire.view;

import java.io.IOException;

import cs3500.marblesolitaire.model.hw02.MarbleSolitaireModelState;

/**
 * Represent a text view for a marblesolitaireview. Abstracts code from subclasses and provides
 * common functionality.
 */
public class ATextView implements MarbleSolitaireView {

  protected MarbleSolitaireModelState state;
  protected Appendable destination;

  /**
   * Constructor - make a new ATextView with the provided inputs.
   *     @param state the MarbleSolitaireModelState to be represented.
   *     @param destination the Appendable object to send output to.
   *     @throws IllegalArgumentException if any inputs are null.
   */
  public ATextView(MarbleSolitaireModelState state, Appendable destination)
          throws IllegalArgumentException {
    if (state == null) {
      throw new IllegalArgumentException("MarbleSolitaireModelState state is null :(");
    }
    if (destination == null) {
      throw new IllegalArgumentException("Appendable destination is null :(");
    }
    this.state = state;
    this.destination = destination;
  }

  /**
   * Transmit the state of the board to this View's destination.
   *     @throws IOException if something goes wrong with transmitting the state to the destination.
   */
  @Override
  public void renderBoard() throws IOException {
    destination.append(this + "\n");
  }

  /**
   * Transmit the given message to this View's destination.
   *     @throws IOException if something goes wrong with transmitting the message.
   */
  @Override
  public void renderMessage(String message) throws IOException {
    if (message == null) {
      return;
    }
    destination.append(message);
  }

  /**
   * Remove the spaces from the end of the given string.
   *     @param s the string to be altered.
   *     @return the finished string s, without spaces at the end.
   */
  protected String truncateSpaces(String s) {
    int lastGood = s.length() - 1;
    while (lastGood > 0) {
      if (s.charAt(lastGood) == ' ') {
        lastGood = lastGood - 1;
      } else {
        break;
      }
    }
    return s.substring(0, lastGood + 1);
  }
}
