package cs3500.marblesolitaire.model.hw04;

import java.util.ArrayList;

/**
 * Represent European Solitaire, a solitaire variant with an octagonal board.
 */
public class EuropeanSolitaireModel extends ASolitaireModel {

  /**
   * Constructor - make a new EuropeanSolitaireModel with the default settings.
   */
  public EuropeanSolitaireModel() {
    super(3, 3, 3);
  }

  /**
   * Constructor - make a new EuropeanSolitaireModel with the given input sidelength.
   *     @param sideLength the length of one side of the board.
   *     @throws IllegalArgumentException if sidelength is not a positive number.
   */
  public EuropeanSolitaireModel(int sideLength) throws IllegalArgumentException {
    super(sideLength, sideLength + (sideLength / 2) - 1,
            sideLength + (sideLength / 2) - 1);
  }

  /**
   * Constructor - make a new EuropeanSolitaireModel with the given row/col inputs.
   *     @param row the row position of the empty slot.
   *     @param col the column position of the empty slot.
   *     @throws IllegalArgumentException if the empty slot position described by row and col would
   *     be out-of-bounds.
   */
  public EuropeanSolitaireModel(int row, int col) throws IllegalArgumentException {
    super(3, row, col);
  }

  /**
   * Constructor - make a new EuropeanSolitaireModel with the given inputs.
   *     @param sideLength the length of one side of the board.
   *     @param row the row position for the empty slot.
   *     @param col the column position for the empty slot.
   *     @throws IllegalArgumentException if the position described by row and col would be
   *     invalid for an empty slot.
   */
  public EuropeanSolitaireModel(int sideLength, int row, int col) throws IllegalArgumentException {
    super(sideLength, row, col);
  }

  /**
   * Set up the board by initializing all SlotStates to their proper values based on
   * the given sideLength and empty slot coordinates. Relies on having valid inputs.
   *     @param sideLength the sideLength for the EuropeanSolitaireModel.
   *     @param row the row position of the empty slot.
   *     @param col the column position of the empty slot.
   */
  protected void generateGrid(int sideLength, int row, int col) {
    int boardSize = this.getBoardSize();
    ArrayList<ArrayList<SlotState>> theList = new ArrayList<ArrayList<SlotState>>();
    for (int i = 0; i < boardSize; i = i + 1) {
      ArrayList<SlotState> theRow = new ArrayList<SlotState>();

      for (int j = 0; j < boardSize; j = j + 1) {
        SlotState temp;

        if ((i < sideLength - 1) &&
                (j < sideLength - 1 - i || j >= 2 * sideLength - 1 + i)) {
          temp = SlotState.Invalid;
        } else if (i >= 2 * sideLength - 1 &&
                (j < sideLength - 1 - (boardSize - 1 - i)
                        || j >= 2 * sideLength - 1 + (boardSize - 1 - i))) {
          temp = SlotState.Invalid;
        } else if (i == row && j == col) {
          temp = SlotState.Empty;
        } else {
          temp = SlotState.Marble;
        }

        theRow.add(temp);
      }
      theList.add(theRow);
    }
    this.grid = theList;
  }

  /**
   * Compute and return the size of the board, a rough estimate of its longest measurement.
   *     @return the size, as an int.
   */
  @Override
  public int getBoardSize() {
    return 3 * super.dimensions - 2;//this.sidelength
  }

  /**
   * Is the size acceptable for the EuropeanSolitaireModel?.
   *     @param size the given size, a representation of the size of the board.
   *     @return true if the size is acceptable.
   */
  @Override
  protected boolean sizeOk(int size) {
    return size > 2 && size % 2 == 1;
  }

  /**
   * Is the position specified by row and col a valid position on the board?.
   *     @param row the row coordinate for the position.
   *     @param col the column coordinate for the position.
   *     @return true if the position is valid, false otherwise.
   */
  protected boolean isPositionOk(int row, int col) {
    //System.out.println(row + " " +  col);
    int size = this.getBoardSize();
    int sideLength = super.dimensions;
    return row >= 0 && col >= 0 && row < size && col < size &&
            !((row < sideLength - 1) &&
                    (col < sideLength - 1 - row || col >= 2 * sideLength - 1 + row)) &&
            !(row >= 2 * sideLength - 1 &&
                    (col < sideLength - 1 - (size - 1 - row)
                            || col >= 2 * sideLength - 1 + (size - 1 - row)));
  }

}
