import java.io.IOException;
import java.util.Objects;

import cs3500.marblesolitaire.view.MarbleSolitaireView;

/**
 * A marblesolitaireview that only exists to test things.
 */
public class RecordingView implements MarbleSolitaireView {

  final StringBuilder log;
  final MarbleSolitaireView view;

  public RecordingView(StringBuilder log, MarbleSolitaireView view) {
    this.log = Objects.requireNonNull(log);
    this.view = view;
  }

  @Override
  public void renderBoard() throws IOException {
    this.log.append(view.toString() + "\n");
  }

  @Override
  public void renderMessage(String message) throws IOException {
    this.log.append(message);
  }

  public String getLog() {
    return this.log.toString();
  }

  public String toString() {
    return this.view.toString();
  }

}
