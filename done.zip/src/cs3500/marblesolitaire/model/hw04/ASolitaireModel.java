package cs3500.marblesolitaire.model.hw04;

import java.util.ArrayList;

import cs3500.marblesolitaire.model.hw02.MarbleSolitaireModel;
import cs3500.marblesolitaire.model.hw02.MarbleSolitaireModelState;

/**
 * This class represents a solitaire model, and provides necessary functionality, abstracting out
 * duplicated code from its subclasses.
 */
public abstract class ASolitaireModel implements MarbleSolitaireModel, MarbleSolitaireModelState {

  protected ArrayList<ArrayList<SlotState>> grid; // the list of states that represent the board.
  protected int dimensions; //a number representing the size of the board in some way.

  /**
   * Constructor - make a new ASolitaireModel with the given inputs.
   *     @param dimensions a numerical value representing the size of the board.
   *     @param row the row position for the empty slot on the board.
   *     @param col the column position for the empty slot on the board.
   *     @throws IllegalArgumentException if the dimension or row/col position are illegal
   *     by the definition of whatever subclass calls the ASolitaireModel constructor.
   */
  public ASolitaireModel(int dimensions, int row, int col) throws IllegalArgumentException {
    if (!sizeOk(dimensions)) {
      throw new IllegalArgumentException("bad size provided to ASolitaireModel constructor");
    }
    this.dimensions = dimensions;
    if (!isPositionOk(row, col)) {
      throw new IllegalArgumentException("bad position provided to ASolitaireModel constructor");
    }
    this.generateGrid(dimensions, row, col);
  }

  /**
   * Is the game over? Are there any more legal moves to make?.
   *     @return true if there are no more legal moves, false otherwise.
   */
  @Override
  public boolean isGameOver() {
    for (int i = 0; i < this.getBoardSize(); i = i + 1) {
      for (int j = 0; j < this.getBoardSize(); j = j + 1) {
        if (this.canMove(i, j, i + 2, j) || this.canMove(i + 2, j, i, j)
                || this.canMove(i, j, i, j + 2)
                || this.canMove(i, j + 2, i, j)) {
          return false; //there is a legal move
        }
      }
    }
    return true; //all possible moves fail
  }

  /**
   * Compute and return the board size (rough estimate of teh board's longest dimension) as an int.
   *     @return the size as an int.
   */
  @Override
  public abstract int getBoardSize();

  /**
   * Retrieve and return the state of the board at the specified indices.
   *     @param row the row of the position sought, starting at 0
   *     @param col the column of the position sought, starting at 0
   *     @return the SlotState at the specified position on the board.
   *     @throws IllegalArgumentException if the specified position is off the board entirely.
   */
  @Override
  public SlotState getSlotAt(int row, int col) throws IllegalArgumentException {
    if (this.isSlotOk(row, col)) {
      return this.grab(row, col);
    }
    throw new IllegalArgumentException("Failed to getSlotAt: " + row + ", " + col);
  }

  /**
   * 'Grab' and return the target SlotState.
   *     @param row the row position for the target location.
   *     @param col the column position for the target location.
   *     @return the SlotState at the proper place on the grid.
   */
  protected SlotState grab(int row, int col) {
    return this.grid.get(row).get(col);
  }

  /**
   * Return true if the move specified with the given coordinates is legal for this board.
   *     @param fromRow the initial row position.
   *     @param fromCol the initial column position.
   *     @param toRow the target row position.
   *     @param toCol the target column position.
   *     @return true/false if the move specified with the given coordinates is/isn't legal.
   */
  protected boolean canMove(int fromRow, int fromCol, int toRow, int toCol) {
    if (!isPositionOk(fromRow, fromCol) || !isPositionOk(toRow, toCol)) {
      return false; //illegal positions
    }
    if (this.getSlotAt(fromRow, fromCol) != SlotState.Marble ||
            this.getSlotAt(toRow, toCol) != SlotState.Empty) {
      return false; // not picking up a marble, or landing on a non-empty square
    }

    int vDist = Math.abs(fromRow - toRow);
    int hDist = Math.abs(fromCol - toCol);

    //Since vDist and hDist are positive integers, their squares are also positive.
    //Using intuition based off the Pythagorean theorem (useful for calculating distances in 2D),
    //we can force their squares to add to 4, which ensures that one of them is 2 and the other 0:
    //The only squares that are less than 4 (and therefore could be part of a sum of squares to 4)
    // are 0 (0^2), 1 (1^2), and 4 (2^2). Since we add two squares together, neither of them can be
    // 1, (1 + 0,1,4 != 4), and they both cannot be 0 or 4 (0 + 0 != 4 , 4 + 4 != 4). This means one
    //square must be 4 and the other 0, so their roots (the vertical and horizontal distances
    // between points) must be 2 and 0, respectively. This means if and only if
    // ((vDist * vDist) + (hDist * hDist) == 4), the distances are allowable for a move within
    // the rules of the game, so we throw the move out if that isn't the case.
    if ((vDist * vDist) + (hDist * hDist) != 4) {
      return false; //improper distancing from start to end points
    }

    int [] mids = this.midpoint(fromRow, fromCol, toRow, toCol);

    return (this.getSlotAt(mids[0], mids[1]) == SlotState.Marble);

  }

  /**
   * Set up the board by initializing all SlotStates to their proper values based on
   * the given sideLength and empty slot coordinates. Relies on having valid inputs.
   *     @param dimensions the dimensions for the ASolitaireModel.
   *     @param row the row position of the empty slot.
   *     @param col the column position of the empty slot.
   */
  protected abstract void generateGrid(int dimensions, int row, int col);


  /**
   * Move a single marble from a given position to another given position.
   * A move is valid only if the from and to positions are valid, the marble 'jumps' another
   * during the move, and the endpoints of the move are 2 units apart.
   *
   *     @param fromRow the row number of the position to be moved from
   *                (starts at 0)
   *     @param fromCol the column number of the position to be moved from
   *                (starts at 0)
   *     @param toRow   the row number of the position to be moved to
   *                (starts at 0)
   *     @param toCol   the column number of the position to be moved to
   *                (starts at 0)
   *     @throws IllegalArgumentException if the move is not possible
   */
  public void move(int fromRow, int fromCol,
                      int toRow, int toCol) throws IllegalArgumentException {
    if (this.canMove(fromRow, fromCol, toRow, toCol)) {

      this.grid.get(fromRow).set(fromCol, SlotState.Empty);
      int [] mids = this.midpoint(fromRow, fromCol, toRow, toCol);
      this.grid.get(mids[0]).set(mids[1], SlotState.Empty);
      this.grid.get(toRow).set(toCol, SlotState.Marble);

    } else {
      throw new IllegalArgumentException("Illegal Move: (" + fromRow + "," + fromCol + ") to ("
              + toRow + "," + toCol + ")");
    }
  }

  /**
   * Calculate and return the midpoints of the move in array format.
   *     @param fromRow the initial row position.
   *     @param fromCol the initial column position.
   *     @param toRow the target row position.
   *     @param toCol the target column position.
   *     @return the midpoints of the move in array format, row [0], then column [1].
   */
  protected int [] midpoint(int fromRow, int fromCol, int toRow, int toCol) {
    int dRow = toRow - fromRow;
    int dCol = toCol - fromCol;
    int midRow = dRow / 2;
    int midCol = dCol / 2;
    return new int []{fromRow + midRow, fromCol + midCol};
  }

  /**
   * How many marbles are left? That's your score.
   *     @return the score as an int.
   */
  @Override
  public int getScore() {
    int count = 0;
    for (ArrayList<SlotState> row: this.grid) {
      for (SlotState state: row) {
        if (state == SlotState.Marble) {
          count = count + 1;
        }
      }
    }
    return count;
  }

  /**
   * Should the given position be a non-invalid SlotState?.
   *     @return true if yes, false otherwise.
   */
  protected abstract boolean isPositionOk(int row, int col);

  /**
   * Is the size acceptable for the ASolitaireModel?.
   *     @param size the given size, a representation of the size of the board.
   *     @return true if the size is acceptable.
   */
  protected abstract boolean sizeOk(int size);

  /**
   * Is the given position on the board at all?.
   *     @param row the row coordinate for the target position.
   *     @param col the column coordinate for the target position.
   *     @return true if the given position on the board at all, false otherwise.
   */
  protected boolean isSlotOk(int row, int col) {
    int size = this.getBoardSize();
    return row >= 0 && col >= 0 && row < size && col < size;
  }
}
