import cs3500.marblesolitaire.model.hw02.MarbleSolitaireModel;

/**
 * A marblesolitairemodel that only exists to test things.
 */
public class RecordingModel implements MarbleSolitaireModel {

  final StringBuilder log;
  final MarbleSolitaireModel model;

  public RecordingModel(StringBuilder log, MarbleSolitaireModel model) {
    this.log = log;
    this.model = model;
  }

  @Override
  public void move(int fromRow, int fromCol, int toRow, int toCol) throws IllegalArgumentException {
    this.log.append("Move: " + fromRow + " " + fromCol + " " + toRow + " " + toCol);
    this.model.move(fromRow, fromCol, toRow, toCol);
  }

  public String getLog() {
    return this.log.toString();
  }

  @Override
  public boolean isGameOver() {
    return this.model.isGameOver();
  }

  @Override
  public int getBoardSize() {
    return this.model.getBoardSize();
  }

  @Override
  public SlotState getSlotAt(int row, int col) throws IllegalArgumentException {
    return this.model.getSlotAt(row, col);
  }

  @Override
  public int getScore() {
    return this.model.getScore();
  }
}
