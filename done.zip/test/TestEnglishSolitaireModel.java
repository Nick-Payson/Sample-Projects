import org.junit.Before;
import org.junit.Test;

import cs3500.marblesolitaire.model.hw02.EnglishSolitaireModel;
import cs3500.marblesolitaire.model.hw02.MarbleSolitaireModelState;
import cs3500.marblesolitaire.model.hw04.ASolitaireModel;

import cs3500.marblesolitaire.view.MarbleSolitaireTextView;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

/**
 * Test the EnglishSolitaireModel and MarbleSolitaireTextView classes.
 */
public class TestEnglishSolitaireModel {

  //Declaring some useful objects for testing
  ASolitaireModel test1;
  MarbleSolitaireTextView view1;
  ASolitaireModel test2;
  MarbleSolitaireTextView view2;
  ASolitaireModel test3;
  MarbleSolitaireTextView view3;
  ASolitaireModel test4;
  MarbleSolitaireTextView view4;

  /**
   * Preliminary setup for testing, initialize each model and view with the appropriate constructor.
   */
  @Before
  public void setup() {
    test1 = new EnglishSolitaireModel();
    view1 = new MarbleSolitaireTextView(test1);
    test2 = new EnglishSolitaireModel(2, 4);
    view2 = new MarbleSolitaireTextView(test2);
    test3 = new EnglishSolitaireModel(5);
    view3 = new MarbleSolitaireTextView(test3);
    test4 = new EnglishSolitaireModel(3, 3, 3);
    view4 = new MarbleSolitaireTextView(test4);
  }

  /**
   * Test all constructors with valid inputs. Confirm objects are created, boardSize is correct
   * (proving armThickness is correct), and check the board states to confirm proper board size
   *  and placement of empty slot.
   */
  @Test
  public void testGoodConstructors() {
    //Since testView works, we know that with a proper output string,
    // the board is initialized properly.

    //testing basic constructor, assigns empty spot to 3,3
    assertTrue(test1 != null);
    assertEquals(test1.getBoardSize(), 7);
    assertEquals(view1.toString(), "    O O O\n" +
            "    O O O\n" +
            "O O O O O O O\n" +
            "O O O _ O O O\n" +
            "O O O O O O O\n" +
            "    O O O\n" +
            "    O O O");

    //testing second constructor, assigns empty spot to sRow, sCol (2,4)
    assertTrue(test2 != null);
    assertEquals(test2.getBoardSize(), 7);
    assertEquals(view2.toString(), "    O O O\n" +
            "    O O O\n" +
            "O O O O _ O O\n" +
            "O O O O O O O\n" +
            "O O O O O O O\n" +
            "    O O O\n" +
            "    O O O");

    //testing third constructor, assigns empty spot to middle, variable board size.
    //(armthickness 5, boardsize = 13)
    assertTrue(test3 != null);
    assertEquals(test3.getBoardSize(), 13);
    assertEquals("        O O O O O\n" +
            "        O O O O O\n" +
            "        O O O O O\n" +
            "        O O O O O\n" +
            "O O O O O O O O O O O O O\n" +
            "O O O O O O O O O O O O O\n" +
            "O O O O O O _ O O O O O O\n" +
            "O O O O O O O O O O O O O\n" +
            "O O O O O O O O O O O O O\n" +
            "        O O O O O\n" +
            "        O O O O O\n" +
            "        O O O O O\n" +
            "        O O O O O", view3.toString());

    //testing third constructor, assigns empty spot to middle, variable board size.
    //(armthickness 3, boardsize = 7)
    test3 = new EnglishSolitaireModel(3);
    view3 = new MarbleSolitaireTextView(test3);

    assertTrue(test3 != null);
    assertEquals(test3.getBoardSize(), 7);
    assertEquals(view1.toString(), "    O O O\n" +
            "    O O O\n" +
            "O O O O O O O\n" +
            "O O O _ O O O\n" +
            "O O O O O O O\n" +
            "    O O O\n" +
            "    O O O");

    //testing fourth constructor, assigns empty spot to sRow, sCol (3,3), (armThickness = 3)
    assertTrue(test4 != null);
    assertEquals(test4.getBoardSize(), 7);
    assertEquals(view4.toString(), "    O O O\n" +
            "    O O O\n" +
            "O O O O O O O\n" +
            "O O O _ O O O\n" +
            "O O O O O O O\n" +
            "    O O O\n" +
            "    O O O");

    test4 = new EnglishSolitaireModel(5, 7, 8);
    view4 = new MarbleSolitaireTextView(test4);
    //testing fourth constructor, assigns empty spot to sRow, sCol (7,8), (armThickness = 5)
    assertTrue(test4 != null);
    assertEquals(test4.getBoardSize(), 13);
    assertEquals("        O O O O O\n" +
            "        O O O O O\n" +
            "        O O O O O\n" +
            "        O O O O O\n" +
            "O O O O O O O O O O O O O\n" +
            "O O O O O O O O O O O O O\n" +
            "O O O O O O O O O O O O O\n" +
            "O O O O O O O O _ O O O O\n" +
            "O O O O O O O O O O O O O\n" +
            "        O O O O O\n" +
            "        O O O O O\n" +
            "        O O O O O\n" +
            "        O O O O O", view4.toString());
  }

  /**
   * Test the second constructor for invalid inputs.
   */
  @Test(expected = IllegalArgumentException.class)
  public void testBadSecondConstructor() {
    //the first constructor cannot throw an error, so this starts with testing the second one.

    EnglishSolitaireModel testBad = new EnglishSolitaireModel(5, 6);
  }

  /**
   * Test the second constructor for invalid inputs.
   */
  @Test(expected = IllegalArgumentException.class)
  public void testBadSecondConstructor2() {
    EnglishSolitaireModel testBad = new EnglishSolitaireModel(-3, 0);
  }

  /**
   * Test the second constructor for invalid inputs.
   */
  @Test(expected = IllegalArgumentException.class)
  public void testBadSecondConstructor3() {
    EnglishSolitaireModel testBad = new EnglishSolitaireModel(50, 3);
  }

  /**
   * Test the third constructor for invalid inputs.
   */
  @Test(expected = IllegalArgumentException.class)
  public void testBadThirdConstructor() {
    EnglishSolitaireModel testBad = new EnglishSolitaireModel(6);
  }

  /**
   * Test the third constructor for invalid inputs.
   */
  @Test(expected = IllegalArgumentException.class)
  public void testBadThirdConstructor2() {
    EnglishSolitaireModel testBad = new EnglishSolitaireModel(-3);
  }

  /**
   * Test the third constructor for invalid inputs.
   */
  @Test(expected = IllegalArgumentException.class)
  public void testBadThirdConstructor3() {
    EnglishSolitaireModel testBad = new EnglishSolitaireModel(0);
  }

  /**
   * Test the fourth constructor for invalid inputs.
   */
  @Test(expected = IllegalArgumentException.class)
  public void testBadFourthConstructorPos() {
    EnglishSolitaireModel testBad = new EnglishSolitaireModel(5, 0, 3);
  }

  /**
   * Test the fourth constructor for invalid inputs.
   */
  @Test(expected = IllegalArgumentException.class)
  public void testBadFourthConstructorArmThickness() {
    EnglishSolitaireModel testBad = new EnglishSolitaireModel(4, 5, 5);
  }

  /**
   * Test the fourth constructor for invalid inputs.
   */
  @Test(expected = IllegalArgumentException.class)
  public void testBadFourthConstructorPos2() {
    EnglishSolitaireModel testBad = new EnglishSolitaireModel(3, 5, 5);
  }

  /**
   * Test the fourth constructor for invalid inputs.
   */
  @Test(expected = IllegalArgumentException.class)
  public void testBadFourthConstructorArmThickness2() {
    EnglishSolitaireModel testBad = new EnglishSolitaireModel(-3, 5, 5);
  }

  /**
   * Test getScore.
   */
  @Test
  public void testGetScore() {
    assertEquals(test1.getScore(), 32);
    test1.move(3, 1, 3, 3);
    test1.move(5, 2, 3, 2);
    test1.move(3, 3, 3, 1);
    assertEquals(test1.getScore(), 29);

    assertEquals(test3.getScore(), 104);
  }

  /**
   * Test getSlotAt with valid inputs.
   */
  @Test
  public void testGetSlotAtGood() {
    assertEquals(test1.getSlotAt(0, 0), MarbleSolitaireModelState.SlotState.Invalid);
    assertEquals(test1.getSlotAt(3, 3), MarbleSolitaireModelState.SlotState.Empty);
    assertEquals(test1.getSlotAt(0, 3), MarbleSolitaireModelState.SlotState.Marble);
    assertEquals(test1.getSlotAt(3, 1), MarbleSolitaireModelState.SlotState.Marble);
    assertEquals(test1.getSlotAt(3, 2), MarbleSolitaireModelState.SlotState.Marble);

    test1.move(3, 1, 3, 3);
    assertEquals(test1.getSlotAt(3, 1), MarbleSolitaireModelState.SlotState.Empty);
    assertEquals(test1.getSlotAt(3, 3), MarbleSolitaireModelState.SlotState.Marble);
    assertEquals(test1.getSlotAt(3, 2), MarbleSolitaireModelState.SlotState.Empty);
  }

  /**
   * Test getSlotAt with invalid inputs.
   */
  @Test(expected = IllegalArgumentException.class)
  public void testGetSlotAtBad1() {
    test1.getSlotAt(7,2);
  }

  /**
   * Test getSlotAt with invalid inputs.
   */
  @Test(expected = IllegalArgumentException.class)
  public void testGetSlotAtBad2() {
    test1.getSlotAt(-400,2);
  }

  /**
   * Test getSlotAt with invalid inputs.
   */
  @Test(expected = IllegalArgumentException.class)
  public void testGetSlotAtBad3() {
    test3.getSlotAt(2,13);
  }

  /**
   * Test getSlotAt with invalid inputs.
   */
  @Test(expected = IllegalArgumentException.class)
  public void testGetSlotAtBad4() {
    test3.getSlotAt(2,-200);
  }

  /**
   * Test getBoardSize.
   */
  @Test
  public void testGetBoardSize() {
    assertEquals(test1.getBoardSize(), 7);
    assertEquals(test3.getBoardSize(), 13);
    assertEquals(new EnglishSolitaireModel(9).getBoardSize(), 25);
  }


  /**
   * Test move with valid inputs, confirm after move that board state has changed appropriately.
   */
  @Test
  public void testGoodMove() {
    assertEquals(view1.toString(), "    O O O\n" +
            "    O O O\n" +
            "O O O O O O O\n" +
            "O O O _ O O O\n" +
            "O O O O O O O\n" +
            "    O O O\n" +
            "    O O O");

    test1.move(3, 1, 3, 3);
    test1.move(5, 2, 3, 2);
    test1.move(3, 3, 3, 1);
    test1.move(5, 3, 3, 3);

    assertEquals(view1.toString(), "    O O O\n" +
            "    O O O\n" +
            "O O O O O O O\n" +
            "O O _ O O O O\n" +
            "O O _ _ O O O\n" +
            "    _ _ O\n" +
            "    O O O");

    assertEquals("        O O O O O\n" +
            "        O O O O O\n" +
            "        O O O O O\n" +
            "        O O O O O\n" +
            "O O O O O O O O O O O O O\n" +
            "O O O O O O O O O O O O O\n" +
            "O O O O O O _ O O O O O O\n" +
            "O O O O O O O O O O O O O\n" +
            "O O O O O O O O O O O O O\n" +
            "        O O O O O\n" +
            "        O O O O O\n" +
            "        O O O O O\n" +
            "        O O O O O", view3.toString());

    test3.move(6, 4, 6, 6);
    test3.move(4, 4, 6, 4);
    test3.move(5, 2, 5, 4);

    assertEquals("        O O O O O\n" +
            "        O O O O O\n" +
            "        O O O O O\n" +
            "        O O O O O\n" +
            "O O O O _ O O O O O O O O\n" +
            "O O _ _ O O O O O O O O O\n" +
            "O O O O O _ O O O O O O O\n" +
            "O O O O O O O O O O O O O\n" +
            "O O O O O O O O O O O O O\n" +
            "        O O O O O\n" +
            "        O O O O O\n" +
            "        O O O O O\n" +
            "        O O O O O", view3.toString());
  }

  /**
   * Test move with invalid inputs.
   */
  @Test(expected = IllegalArgumentException.class)
  public void testBadMoveInvalidPos1() {
    test1.move(-1, 0, 1, 0);
  }

  /**
   * Test move with invalid inputs.
   */
  @Test(expected = IllegalArgumentException.class)
  public void testBadMoveInvalidPos2() {
    test1.move(3, -1, 1, -1);
  }

  /**
   * Test move with invalid inputs.
   */
  @Test(expected = IllegalArgumentException.class)
  public void testBadMoveInvalidPos3() {
    test1.move(2, 0, 0, 0);
  }

  /**
   * Test move with invalid inputs.
   */
  @Test(expected = IllegalArgumentException.class)
  public void testBadMoveInvalidPos4() {
    test1.move(3, 4, 3, 6);
  }

  /**
   * Test move with invalid inputs.
   */
  @Test(expected = IllegalArgumentException.class)
  public void testBadMoveIllegalStartState() {
    test1.move(3, 3, 5, 3);
  }

  /**
   * Test move with invalid inputs.
   */
  @Test(expected = IllegalArgumentException.class)
  public void testBadMoveIllegalEndState() {
    test1.move(3, 2, 3, 4);
  }

  /**
   * Test move with invalid inputs.
   */
  @Test(expected = IllegalArgumentException.class)
  public void testBadMoveIllegalSpacing1() {
    test1.move(3, 0, 3, 3);
  }

  /**
   * Test move with invalid inputs.
   */
  @Test(expected = IllegalArgumentException.class)
  public void testBadMoveIllegalSpacing2() {
    test1.move(3, 2, 3, 3);
  }

  /**
   * Test move with invalid inputs.
   */
  @Test(expected = IllegalArgumentException.class)
  public void testBadMoveIllegalSpacing3() {
    test3.move(4, 4, 6, 6);
  }

  /**
   * Test move with invalid inputs.
   */
  @Test(expected = IllegalArgumentException.class)
  public void testBadMoveIllegalSpacing4() {
    test3.move(5, 0, 6, 6);
  }

  /**
   * Test move with invalid inputs.
   */
  @Test(expected = IllegalArgumentException.class)
  public void testBadMoveIllegalJump() {
    test1.move(3, 1, 3, 3);
    assertEquals(view1.toString(), "    O O O\n" +
            "    O O O\n" +
            "O O O O O O O\n" +
            "O _ _ O O O O\n" +
            "O O O O O O O\n" +
            "    O O O\n" +
            "    O O O"); //still ok here, the next move causes the failure
    test1.move(3, 0, 3, 2);
  }

  /**
   * Test move with invalid inputs.
   */
  @Test(expected = IllegalArgumentException.class)
  public void testBadMoveIllegalJump2() {
    test1.move(1, 3, 3, 3);
    assertEquals(view1.toString(), "    O O O\n" +
            "    O _ O\n" +
            "O O O _ O O O\n" +
            "O O O O O O O\n" +
            "O O O O O O O\n" +
            "    O O O\n" +
            "    O O O"); //still ok here, the next move causes the failure
    test1.move(0, 3, 2, 3);
  }

  /**
   * Test move with invalid inputs. Confirm that the board state does not change upon invalid move.
   */
  @Test
  public void testNotMoving() {
    try {
      assertEquals(view1.toString(), "    O O O\n" +
              "    O O O\n" +
              "O O O O O O O\n" +
              "O O O _ O O O\n" +
              "O O O O O O O\n" +
              "    O O O\n" +
              "    O O O");
      test1.move(3,3,3,3);
    } catch (IllegalArgumentException e) {
      assertEquals(view1.toString(), "    O O O\n" +
              "    O O O\n" +
              "O O O O O O O\n" +
              "O O O _ O O O\n" +
              "O O O O O O O\n" +
              "    O O O\n" +
              "    O O O");
    }
  }

  /**
   * Test isGameOver.
   */
  @Test
  public void testIsGameOver() {
    test1.move(5,3,3,3);
    test1.move(4,5,4,3);
    test1.move(6,4,4,4);
    test1.move(6,2,6,4);
    test1.move(3,4,5,4);
    test1.move(6,4,4,4);
    test1.move(1,4,3,4);
    test1.move(2,6,2,4);
    test1.move(4,6,2,6);
    test1.move(2,3,2,5);
    test1.move(2,6,2,4);
    test1.move(2,1,2,3);
    test1.move(0,2,2,2);
    test1.move(0,4,0,2);
    test1.move(3,2,1,2);
    test1.move(0,2,2,2);
    test1.move(5,2,3,2);
    test1.move(4,0,4,2);
    test1.move(2,0,4,0);
    test1.move(4,3,4,1);
    test1.move(4,0,4,2);
    test1.move(2,3,2,1);
    test1.move(2,1,4,1);
    test1.move(4,1,4,3);
    test1.move(4,3,4,5);
    test1.move(4,5,2,5);
    test1.move(2,5,2,3);
    test1.move(3,3,3,5);
    test1.move(1,3,3,3);
    assertFalse(test1.isGameOver());
    test1.move(3,2,3,4);
    test1.move(3,5,3,3);
    assertTrue(test1.isGameOver());
  }

  //Now testing MarbleSolitaireTextView.

  /**
   * Test TextView Constructor with valid inputs.
   */
  @Test
  public void testTextViewConstructorGood() {
    assertTrue(view1 != null);

    //to confirm state is passed in correctly
    assertEquals(view1.toString(), "    O O O\n" +
            "    O O O\n" +
            "O O O O O O O\n" +
            "O O O _ O O O\n" +
            "O O O O O O O\n" +
            "    O O O\n" +
            "    O O O");
  }

  /**
   * Test TextView Constructor with invalid inputs.
   */
  @Test(expected = IllegalArgumentException.class)
  public void testTextViewConstructorBad() {
    MarbleSolitaireTextView badView = new MarbleSolitaireTextView(null);
  }

  /**
   * Test TextView toString. Confirm the right String symbols correspond to the right SlotStates.
   */
  @Test
  public void testTextViewToString() {
    //confirm proper strings for state values in tandem with testing view in string format.
    assertEquals(test1.getSlotAt(0, 0), MarbleSolitaireModelState.SlotState.Invalid);
    assertEquals(test1.getSlotAt(3, 3), MarbleSolitaireModelState.SlotState.Empty);
    assertEquals(test1.getSlotAt(0, 3), MarbleSolitaireModelState.SlotState.Marble);

    assertEquals(view1.toString(), "    O O O\n" +
            "    O O O\n" +
            "O O O O O O O\n" +
            "O O O _ O O O\n" +
            "O O O O O O O\n" +
            "    O O O\n" +
            "    O O O");

    test1.move(3, 1, 3, 3);
    test1.move(5, 2, 3, 2);
    test1.move(3, 3, 3, 1);

    assertEquals(view1.toString(), "    O O O\n" +
            "    O O O\n" +
            "O O O O O O O\n" +
            "O O _ _ O O O\n" +
            "O O _ O O O O\n" +
            "    _ O O\n" +
            "    O O O");

    assertEquals("        O O O O O\n" +
            "        O O O O O\n" +
            "        O O O O O\n" +
            "        O O O O O\n" +
            "O O O O O O O O O O O O O\n" +
            "O O O O O O O O O O O O O\n" +
            "O O O O O O _ O O O O O O\n" +
            "O O O O O O O O O O O O O\n" +
            "O O O O O O O O O O O O O\n" +
            "        O O O O O\n" +
            "        O O O O O\n" +
            "        O O O O O\n" +
            "        O O O O O", view3.toString());
  }


}




