package cs3500.marblesolitaire.controller;

import java.io.IOException;

import java.util.ArrayList;
import java.util.Scanner;

import cs3500.marblesolitaire.model.hw02.MarbleSolitaireModel;
import cs3500.marblesolitaire.view.MarbleSolitaireView;

/**
 * Marble Solitaire Controller Implementation class, for playing a game of marble solitaire.
 * Handles input from user / mock user and sends appropriate commands to the model.
 * Uses the View to display the Model as necessary.
 * Plays the game from beginning to end, and can quit at any time.
 */
public class MarbleSolitaireControllerImpl implements MarbleSolitaireController {

  private MarbleSolitaireModel model; //the model to be used
  private MarbleSolitaireView view; // the view to display with
  private Readable in; //the source of input, the 'user'
  private final ArrayList<String> moves; //the move to be made in the game, stored in an arraylist.
  private boolean quit; //is the game quit?
  private ArrayList<String> extras;
  private Scanner reader;

  /**
   * Constructor - make a new MarbleSolitaireControllerImpl and instantiate its fields.
   *
   *     @param model - the SolitaireModel this controller controls.
   *     @param view  - the view this controller outputs to.
   *     @param in    - the Readable this controller receives input from.
   *     @throws IllegalArgumentException if supplied fields are null.
   */
  public MarbleSolitaireControllerImpl(MarbleSolitaireModel model, MarbleSolitaireView view,
                                       Readable in) throws IllegalArgumentException {

    if (model == null || view == null || in == null) {
      throw new IllegalArgumentException("Null input to MarbleSolitaireControllerImpl");
    }

    this.model = model;
    this.view = view;
    this.in = in;
    this.moves = new ArrayList<String>();
    this.reader = new Scanner(in);
    this.quit = false;
  }

  /**
   * Is the given input String a potentially valid input for a move?.
   *     @param s the input string.
   *     @return true if s is potentially valid, false otherwise.
   */
  private boolean inputOk(String s) {

    char[] nums = new char[]{'1', '2', '3', '4', '5', '6', '7', '8', '9', '0'};
    boolean stringOk = false;

    if (s.length() > 0) {
      stringOk = true;
    }

    for (int j = 0; j < s.length(); j++) {
      boolean charOk = false;

      for (int k = 0; k < 10; k++) {
        if (s.charAt(j) == (nums[k])) {
          charOk = true;
        }
      }

      if (!charOk) {
        stringOk = false;
      }

    }
    return stringOk;
  }

  /**
   * Fill in invalid inputs with new numbers.
   *
   *     @param s - the new input to be applied.
   **/
  private void handleInput(String s) {

    if (s.equalsIgnoreCase("q")) {
      quitSequence();
      return;
    }

    if (inputOk(s)) {
      this.moves.add(s);
    }
  }

  /**
   * Is the move ready?.
   * The move is ready if there are 4 inputs in the 'moves' ArrayList.
   *     @return
   */
  private boolean moveReady() {
    return this.moves.size() == 4; //assuming all are valid inputs, which will happen
  }

  /**
   * Execute this when quitting to display required output.
   *     @throws IllegalStateException if there is a problem with handling the output.
   */
  private void quitSequence() throws IllegalStateException {
    this.quit = true;
    try {
      view.renderMessage("Game quit!\n" + "State of game when quit:\n" + view.toString()
              + "\n" + "Score: " + model.getScore() + "\n");
    } catch (IOException e) {

      throw new IllegalStateException("message failed to render");
    }
  }

  /**
   * Execute this when ending normally to display required output.
   *     @throws IllegalStateException if there is a problem with handling the output.
   */
  private void normalEnd() throws IllegalStateException {
    try {
      view.renderMessage("Game over!\n" + view + "\n" + "Score: " + model.getScore());
    } catch (IOException e) {

      throw new IllegalStateException("message failed to render");
    }
  }

  /**
   * Reset the move ArrayList.
   * Not really a necessary method, just makes it more readable.
   */
  private void resetMove() {
    this.moves.clear();
  }

  /**
   * Is the given input string 'meaningful' to the game's operation?.
   * 'meaningful' = number or quit command.
   *     @param input the input string to be checked.
   *     @return true if the input is 'meaningful', false otherwise.
   */
  private boolean meaningfulInput(String input) {
    return inputOk(input) || input.equalsIgnoreCase("q");
  }

  /**
   * Plays the game with the given input and output.
   *     @throws IllegalStateException if the controller cannot properly handle the input.
   */
  public void playGame() throws IllegalStateException {
    Scanner secondary = new Scanner(in);
    String next = "";

    while (!model.isGameOver()) {

      if (moveReady()) { //do the move if there is one.

        try {
          model.move(Integer.parseInt(moves.get(0)) - 1,
                  Integer.parseInt(moves.get(1)) - 1,
                  Integer.parseInt(moves.get(2)) - 1,
                  Integer.parseInt(moves.get(3)) - 1);

        } catch (IllegalArgumentException e) {
          try {

            view.renderMessage("Invalid move. Play again. :)\n");
          } catch (IOException f) {
            throw new IllegalStateException(f.getMessage());
          }
        }

        resetMove(); //reset the move ArrayList to prepare for next cycle.

      }

      if (newMove() && !quit) { //if it's a new move, display the board.
        showState();
      }

      if (reader.hasNext() && !quit) {
        next = reader.next();
        if (meaningfulInput(next)) {
          handleInput(next);

          if (quit) {
            return;
          }

        } else if (!quit && !model.isGameOver()) {
          try {
            view.renderMessage("bad input, try again ");
          } catch (IOException e) {
            throw new IllegalStateException(e.getMessage());
          }
        }
      } else if (reader.hasNext()) {

        if (secondary.hasNext()) {
          String next2 = secondary.next();

          if (meaningfulInput(next2)) {
            handleInput(next2);

            if (quit) {
              return;
            }
          }
        }

      } else if (!model.isGameOver()) { //&& !quit?
        throw new IllegalStateException("ran out of input ");
      }

    }

    normalEnd();
  }

  /**
   * Display the state of the game using the provided view.
   *     @throws IllegalStateException if there is a problem handling the output.
   */
  private void showState() throws IllegalStateException {
    try {
      view.renderBoard();
      view.renderMessage("Score: " + model.getScore() + "\n");
    } catch (IOException e) {
      throw new IllegalStateException(e.getMessage());
    }
  }

  /**
   * Is the game ready for a new move?.
   * The game is ready if the 'moves' ArrayList is empty.
   *     @return true if the game is ready for a new move, false otherwise.
   */
  private boolean newMove() {
    return this.moves.size() == 0;
  }

}
