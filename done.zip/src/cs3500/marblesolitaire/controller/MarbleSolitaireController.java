package cs3500.marblesolitaire.controller;

/**
 * Represent a Marble Solitaire Controller, which plays a game of Marble Solitaire from start
 * to finish.
 */
public interface MarbleSolitaireController {

  /**
   * Plays a new game of Marble Solitaire.
   *     @throws IllegalStateException if the controller is unable to handle input successfully.
   */
  void playGame() throws IllegalStateException;

}
