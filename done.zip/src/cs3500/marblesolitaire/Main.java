package cs3500.marblesolitaire;

import java.io.StringReader;

import cs3500.marblesolitaire.controller.MarbleSolitaireController;
import cs3500.marblesolitaire.controller.MarbleSolitaireControllerImpl;
import cs3500.marblesolitaire.model.hw02.EnglishSolitaireModel;
import cs3500.marblesolitaire.view.MarbleSolitaireTextView;
import cs3500.marblesolitaire.view.MarbleSolitaireView;

/**
 * The Main class, to run the game.
 */
public class Main {

  /**
   * run the game.
   *     @param args the commands to run.
   */
  public static void main(String [] args) {

    EnglishSolitaireModel model = new EnglishSolitaireModel();
    MarbleSolitaireView view = new MarbleSolitaireTextView(model);
    MarbleSolitaireController controller = new MarbleSolitaireControllerImpl(model, view,
            new StringReader(""));
    //controller.playGame();

    /*MarbleSolitaireController c2 = new MarbleSolitaireControllerImpl(model, view,
            new InputStreamReader(System.in));
    c2.playGame();*/

  }
}