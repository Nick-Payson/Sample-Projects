import org.junit.Before;
import org.junit.Test;

import cs3500.marblesolitaire.model.hw02.EnglishSolitaireModel;
import cs3500.marblesolitaire.model.hw02.MarbleSolitaireModelState;
import cs3500.marblesolitaire.model.hw04.ASolitaireModel;
import cs3500.marblesolitaire.model.hw04.TriangleSolitaireModel;
import cs3500.marblesolitaire.view.ATextView;
import cs3500.marblesolitaire.view.TriangleSolitaireTextView;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

/**
 * Test the TriangleSolitaireModel, and all its public functionality.
 */
public class TestTriangleSolitaireModel {

  //useful things for testing
  ASolitaireModel test1;
  ATextView view1;
  ASolitaireModel test2;
  ATextView view2;
  ASolitaireModel test3;
  ATextView view3;
  ASolitaireModel test4;
  ATextView view4;

  /**
   * Convenience stuff, setup this before every test.
   */
  @Before
  public void setup() {
    test1 = new TriangleSolitaireModel();
    view1 = new TriangleSolitaireTextView(test1);
    test2 = new TriangleSolitaireModel(3);
    view2 = new TriangleSolitaireTextView(test2);
    test3 = new TriangleSolitaireModel(2, 1);
    view3 = new TriangleSolitaireTextView(test3);
    test4 = new TriangleSolitaireModel(6, 4, 1);
    view4 = new TriangleSolitaireTextView(test4);
  }

  @Test
  public void testGoodConstructors() {

    //test first constructor
    assertTrue(test1 != null);
    assertEquals(test1.getBoardSize(), 5);
    assertEquals(view1.toString(), "    _\n" +
            "   O O\n" +
            "  O O O\n" +
            " O O O O\n" +
            "O O O O O");

    //test second constructor
    assertTrue(test2 != null);
    assertEquals(test2.getBoardSize(), 3);
    assertEquals(view2.toString(), "  _\n" +
            " O O\n" +
            "O O O");

    //test second constructor with different size
    test2 = new TriangleSolitaireModel(5);
    view2 = new TriangleSolitaireTextView(test2);
    assertTrue(test2 != null);
    assertEquals(test2.getBoardSize(), 5);
    assertEquals(view2.toString(), "    _\n" +
            "   O O\n" +
            "  O O O\n" +
            " O O O O\n" +
            "O O O O O");

    //test third constructor
    assertTrue(test3 != null);
    assertEquals(test3.getBoardSize(), 5);
    assertEquals(view3.toString(), "    O\n" +
            "   O O\n" +
            "  O _ O\n" +
            " O O O O\n" +
            "O O O O O");

    //test fourth constructor
    assertTrue(test4 != null);
    assertEquals(test4.getBoardSize(), 6);
    assertEquals(view4.toString(), "     O\n" +
            "    O O\n" +
            "   O O O\n" +
            "  O O O O\n" +
            " O _ O O O\n" +
            "O O O O O O");

    //test fourth constructor new size
    test4 = new TriangleSolitaireModel(4, 3, 2);
    view4 = new TriangleSolitaireTextView(test4);
    assertTrue(test4 != null);
    assertEquals(test4.getBoardSize(), 4);
    assertEquals(view4.toString(), "   O\n" +
            "  O O\n" +
            " O O O\n" +
            "O O _ O");
  }

  /**
   * Test the second constructor for bad inputs (the first one can't have any).
   */
  @Test(expected = IllegalArgumentException.class)
  public void testBadSecondConstructor() {
    ASolitaireModel testbad = new TriangleSolitaireModel(-1);
  }

  /**
   * Test the second constructor for bad inputs.
   */
  @Test(expected = IllegalArgumentException.class)
  public void testBadSecondConstructor2() {
    ASolitaireModel testbad = new TriangleSolitaireModel(1);
  }

  /**
   * Test the third constructor for bad inputs.
   */
  @Test(expected = IllegalArgumentException.class)
  public void testBadThirdConstructor() {
    ASolitaireModel testbad = new TriangleSolitaireModel(1, -1);
  }

  /**
   * Test the third constructor for bad inputs.
   */
  @Test(expected = IllegalArgumentException.class)
  public void testBadThirdConstructor2() {
    ASolitaireModel testbad = new TriangleSolitaireModel(1, 10);
  }

  /**
   * Test the third constructor for bad inputs.
   */
  @Test(expected = IllegalArgumentException.class)
  public void testBadThirdConstructor3() {
    ASolitaireModel testbad = new TriangleSolitaireModel(10, 3);
  }

  /**
   * Test the third constructor for bad inputs.
   */
  @Test(expected = IllegalArgumentException.class)
  public void testBadThirdConstructor4() {
    ASolitaireModel testbad = new TriangleSolitaireModel(-1, 1);
  }

  /**
   * Test the fourth constructor for bad inputs.
   */
  @Test(expected = IllegalArgumentException.class)
  public void testBadFourthConstructor() {
    ASolitaireModel testbad = new TriangleSolitaireModel(-1, 1, 1);
  }

  /**
   * Test the fourth constructor for bad inputs.
   */
  @Test(expected = IllegalArgumentException.class)
  public void testBadFourthConstructor2() {
    ASolitaireModel testbad = new TriangleSolitaireModel(5, 1, 10);
  }

  /**
   * Test the fourth constructor for bad inputs.
   */
  @Test(expected = IllegalArgumentException.class)
  public void testBadFourthConstructor3() {
    ASolitaireModel testbad = new TriangleSolitaireModel(5, 1, -1);
  }

  /**
   * Test the fourth constructor for bad inputs.
   */
  @Test(expected = IllegalArgumentException.class)
  public void testBadFourthConstructor4() {
    ASolitaireModel testbad = new TriangleSolitaireModel(5, 10, 1);
  }

  /**
   * Test the fourth constructor for bad inputs.
   */
  @Test(expected = IllegalArgumentException.class)
  public void testBadFourthConstructor5() {
    ASolitaireModel testbad = new TriangleSolitaireModel(5, -1, 1);
  }

  /**
   * Test getScore.
   */
  @Test
  public void testGetScore() {
    assertEquals(test1.getScore(), 14);
    test1.move(2, 0, 0, 0);
    test1.move(2, 2, 2, 0);
    test1.move(4, 2, 2, 2);
    assertEquals(test1.getScore(), 11);

    assertEquals(test2.getScore(), 5);
  }

  /**
   * Test getSlotAt with valid inputs.
   */
  @Test
  public void testGetSlotAtGood() {
    assertEquals(test1.getSlotAt(0, 0), MarbleSolitaireModelState.SlotState.Empty);
    assertEquals(test1.getSlotAt(0, 1), MarbleSolitaireModelState.SlotState.Invalid);

    assertEquals(test1.getSlotAt(2, 0), MarbleSolitaireModelState.SlotState.Marble);
    assertEquals(test1.getSlotAt(1, 0), MarbleSolitaireModelState.SlotState.Marble);

    test1.move(2, 0, 0, 0);
    assertEquals(test1.getSlotAt(1, 0), MarbleSolitaireModelState.SlotState.Empty);
    assertEquals(test1.getSlotAt(2, 0), MarbleSolitaireModelState.SlotState.Empty);
    assertEquals(test1.getSlotAt(0, 0), MarbleSolitaireModelState.SlotState.Marble);
  }

  /**
   * Test getSlotAt with invalid inputs.
   */
  @Test(expected = IllegalArgumentException.class)
  public void testGetSlotAtBad1() {
    test1.getSlotAt(7, 2);
  }

  /**
   * Test getSlotAt with invalid inputs.
   */
  @Test(expected = IllegalArgumentException.class)
  public void testGetSlotAtBad2() {
    test1.getSlotAt(0, 20);
  }

  /**
   * Test getSlotAt with invalid inputs.
   */
  @Test(expected = IllegalArgumentException.class)
  public void testGetSlotAtBad3() {
    test1.getSlotAt(-1,0);
  }

  /**
   * Test getSlotAt with invalid inputs.
   */
  @Test(expected = IllegalArgumentException.class)
  public void testGetSlotAtBad4() {
    test1.getSlotAt(3,15);
  }

  /**
   * Test getSlotAt with invalid inputs.
   */
  @Test(expected = IllegalArgumentException.class)
  public void testGetSlotAtBad5() {
    test1.getSlotAt(4,-3);
  }

  /**
   * Test getBoardSize.
   */
  @Test
  public void testGetBoardSize() {
    assertEquals(test1.getBoardSize(), 5);
    assertEquals(test4.getBoardSize(), 6);
    assertEquals(new TriangleSolitaireModel(9).getBoardSize(), 9);
  }

  /**
   * Test valid moves.
   */
  @Test
  public void testGoodMove() {
    assertEquals(view1.toString(), "    _\n" +
            "   O O\n" +
            "  O O O\n" +
            " O O O O\n" +
            "O O O O O");

    test1.move(2, 0, 0, 0); //up right
    test1.move(2, 2, 2, 0); //left
    test1.move(4, 4, 2, 2); //up left
    test1.move(4, 2, 4, 4); //right
    test1.move(2, 0, 4, 2); //down right
    test1.move(4, 0, 2, 0);
    test1.move(4, 2, 4, 0);
    test1.move(2, 2, 4, 2); //down left
    assertEquals(view1.toString(), "    O\n" +
            "   _ O\n" +
            "  O _ _\n" +
            " _ _ _ _\n" +
            "O _ O _ O");
  }

  /**
   * Test a bad move.
   */
  @Test(expected = IllegalArgumentException.class)
  public void testBadMoveInvalidPos() {
    test1.move(-1, 0, 2, 2);
  }

  /**
   * Test a bad move.
   */
  @Test(expected = IllegalArgumentException.class)
  public void testBadMoveInvalidPos2() {
    test1.move(1, -3, 2, 2);
  }

  /**
   * Test a bad move.
   */
  @Test(expected = IllegalArgumentException.class)
  public void testBadMoveInvalidPos3() {
    test1.move(1, 0, 20, 2);
  }

  /**
   * Test a bad move.
   */
  @Test(expected = IllegalArgumentException.class)
  public void testBadMoveInvalidPos4() {
    test1.move(1, 0, 2, -12);
  }

  /**
   * Test a bad move.
   */
  @Test(expected = IllegalArgumentException.class)
  public void testBadMoveIllegalStartState() {
    test1.move(0, 0, 2, 2);
  }

  /**
   * Test a bad move.
   */
  @Test(expected = IllegalArgumentException.class)
  public void testBadMoveIllegalStartState2() {
    test1.move(0, 2, 2, 2);
  }

  /**
   * Test a bad move.
   */
  @Test(expected = IllegalArgumentException.class)
  public void testBadMoveIllegalEndState() {
    test1.move(2, 4, 2, 2);
  }

  /**
   * Test a bad move.
   */
  @Test(expected = IllegalArgumentException.class)
  public void testBadMoveIllegalEndState2() {
    test1.move(1, 1, 1, 3);
  }

  /**
   * Test a bad move.
   */
  @Test(expected = IllegalArgumentException.class)
  public void testBadMoveIllegalSpacing() {
    test1.move(3, 0, 0, 0);
  }

  /**
   * Test a bad move.
   */
  @Test(expected = IllegalArgumentException.class)
  public void testBadMoveIllegalSpacing2() {
    test1.move(1, 1, 0, 0);
  }

  /**
   * Test a bad move.
   */
  @Test(expected = IllegalArgumentException.class)
  public void testBadMoveIllegalJump() {
    test1.move(2, 0, 0, 0); //fine
    test1.move(3, 0, 1, 0); //break it
  }

  /**
   * Test a bad move.
   */
  @Test(expected = IllegalArgumentException.class)
  public void testBadMoveIllegalJump2() {
    test1.move(2, 0, 0, 0); //fine
    test1.move(1, 1, 1, 0); //break it
  }

  /**
   * Test a bad move. Confirm that the board is not updated.
   */
  @Test
  public void testBadMoveNoMovement() {
    test1.move(2, 0, 0, 0); //fine
    try {
      test1.move(3, 0, 1, 0); //break it
    } catch (IllegalArgumentException e) {
      assertEquals(view1.toString(), "    O\n" +
              "   _ O\n" +
              "  _ O O\n" +
              " O O O O\n" +
              "O O O O O");
    }
  }

  @Test
  public void testGameOver() {
    System.out.println(view2.toString());
    test2.move(2, 2, 0, 0);
    test2.move(2, 0, 2, 2);
    assertFalse(test2.isGameOver());
    test2.move(0, 0, 2, 0);
    assertTrue(test2.isGameOver());
  }

  //Now testing TriangleSolitaireTextView.

  /**
   * Test TriangleTextView Constructor with valid inputs.
   */
  @Test
  public void testTextViewConstructorGood() {
    assertTrue(view1 != null);

    //to confirm state is passed in correctly
    assertEquals(view1.toString(), "    _\n" +
            "   O O\n" +
            "  O O O\n" +
            " O O O O\n" +
            "O O O O O");
  }

  /**
   * Test TriangleTextView Constructor with invalid inputs.
   */
  @Test(expected = IllegalArgumentException.class)
  public void testTextViewConstructorBad() {
    ATextView badView = new TriangleSolitaireTextView(null);
  }

  /**
   * Test TriangleTextView Constructor with invalid inputs.
   */
  @Test(expected = IllegalArgumentException.class)
  public void testTextViewConstructorBad2() {
    ATextView badView = new TriangleSolitaireTextView(new EnglishSolitaireModel());
  }

  /**
   * Test the toString method for the view.
   */
  @Test
  public void testTextViewToString() {
    assertEquals(view2.toString(), "  _\n" +
            " O O\n" +
            "O O O");
    test2.move(2, 2, 0, 0);
    test2.move(2, 0, 2, 2);
    test2.move(0, 0, 2, 0);
    assertEquals(view2.toString(), "  _\n" +
            " _ _\n" +
            "O _ O");

    assertEquals(view4.toString(), "     O\n" +
            "    O O\n" +
            "   O O O\n" +
            "  O O O O\n" +
            " O _ O O O\n" +
            "O O O O O O");
  }


}
