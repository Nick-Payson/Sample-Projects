import org.junit.Before;
import org.junit.Test;

import cs3500.marblesolitaire.model.hw02.MarbleSolitaireModelState;
import cs3500.marblesolitaire.model.hw04.ASolitaireModel;
import cs3500.marblesolitaire.model.hw04.EuropeanSolitaireModel;
import cs3500.marblesolitaire.view.MarbleSolitaireTextView;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.assertFalse;

/**
 * Test the EuropeanSolitaireModel.
 */
public class TestEuropeanSolitaireModel {

  ASolitaireModel test1;
  MarbleSolitaireTextView view1;
  ASolitaireModel test2;
  MarbleSolitaireTextView view2;
  ASolitaireModel test3;
  MarbleSolitaireTextView view3;
  ASolitaireModel test4;
  MarbleSolitaireTextView view4;

  /**
   * setup - do before every test for convenience.
   */
  @Before
  public void setup() {
    test1 = new EuropeanSolitaireModel();
    view1 = new MarbleSolitaireTextView(test1);
    test2 = new EuropeanSolitaireModel(5);
    view2 = new MarbleSolitaireTextView(test2);
    test3 = new EuropeanSolitaireModel(2, 3);
    view3 = new MarbleSolitaireTextView(test3);
    test4 = new EuropeanSolitaireModel(5, 6, 4);
    view4 = new MarbleSolitaireTextView(test4);
  }

  @Test
  public void testGoodConstructors() {

    //testing basic constructor, assigns empty spot to 3,3
    assertTrue(test1 != null);
    assertEquals(test1.getBoardSize(), 7);
    assertEquals(view1.toString(), "    O O O\n" +
            "  O O O O O\n" +
            "O O O O O O O\n" +
            "O O O _ O O O\n" +
            "O O O O O O O\n" +
            "  O O O O O\n" +
            "    O O O");

    //testing second constructor, assign side length to 5, empty slot in middle
    assertTrue(test2 != null);
    assertEquals(test2.getBoardSize(), 13);
    assertEquals(view2.toString(), "        O O O O O\n" +
            "      O O O O O O O\n" +
            "    O O O O O O O O O\n" +
            "  O O O O O O O O O O O\n" +
            "O O O O O O O O O O O O O\n" +
            "O O O O O O O O O O O O O\n" +
            "O O O O O O _ O O O O O O\n" +
            "O O O O O O O O O O O O O\n" +
            "O O O O O O O O O O O O O\n" +
            "  O O O O O O O O O O O\n" +
            "    O O O O O O O O O\n" +
            "      O O O O O O O\n" +
            "        O O O O O");

    //testing second constructor, assign side length to 3
    test2 = new EuropeanSolitaireModel(3);
    view2 = new MarbleSolitaireTextView(test2);
    assertTrue(test2 != null);
    assertEquals(test2.getBoardSize(), 7);
    assertEquals(view2.toString(), "    O O O\n" +
            "  O O O O O\n" +
            "O O O O O O O\n" +
            "O O O _ O O O\n" +
            "O O O O O O O\n" +
            "  O O O O O\n" +
            "    O O O");

    //testing third constructor, assigns empty spot to sRow, sCol (2,3)
    assertTrue(test3 != null);
    assertEquals(test3.getBoardSize(), 7);
    assertEquals(view3.toString(), "    O O O\n" +
            "  O O O O O\n" +
            "O O O _ O O O\n" +
            "O O O O O O O\n" +
            "O O O O O O O\n" +
            "  O O O O O\n" +
            "    O O O");

    //testing fourth constructor, assign empty spot to sRow, sCol (6,4), (dimensions = 5)
    assertTrue(test4 != null);
    assertEquals(test4.getBoardSize(), 13);
    assertEquals(view4.toString(), "        O O O O O\n" +
            "      O O O O O O O\n" +
            "    O O O O O O O O O\n" +
            "  O O O O O O O O O O O\n" +
            "O O O O O O O O O O O O O\n" +
            "O O O O O O O O O O O O O\n" +
            "O O O O _ O O O O O O O O\n" +
            "O O O O O O O O O O O O O\n" +
            "O O O O O O O O O O O O O\n" +
            "  O O O O O O O O O O O\n" +
            "    O O O O O O O O O\n" +
            "      O O O O O O O\n" +
            "        O O O O O");

    //testing fourth constructor, assign empty spot to sRow, sCol (1,1), (dimensions = 3)
    test4 = new EuropeanSolitaireModel(3, 1, 1);
    view4 = new MarbleSolitaireTextView(test4);
    assertTrue(test4 != null);
    assertEquals(test4.getBoardSize(), 7);
    assertEquals(view4.toString(), "    O O O\n" +
            "  _ O O O O\n" +
            "O O O O O O O\n" +
            "O O O O O O O\n" +
            "O O O O O O O\n" +
            "  O O O O O\n" +
            "    O O O");
  }

  /**
   * Test the second constructor for invalid inputs.
   * The first constructor cannot throw an error, so this starts with testing the second one.
   */
  @Test(expected = IllegalArgumentException.class)
  public void testBadSecondConstructor() {
    ASolitaireModel testBad = new EuropeanSolitaireModel(4);
  }

  /**
   * Test the second constructor for invalid inputs.
   */
  @Test(expected = IllegalArgumentException.class)
  public void testBadSecondConstructor2() {
    ASolitaireModel testBad = new EuropeanSolitaireModel(1);
  }

  /**
   * Test the second constructor for invalid inputs.
   */
  @Test(expected = IllegalArgumentException.class)
  public void testBadSecondConstructor3() {
    ASolitaireModel testBad = new EuropeanSolitaireModel(-3);
  }

  /**
   * Test the third constructor for invalid inputs.
   */
  @Test(expected = IllegalArgumentException.class)
  public void testBadThirdConstructor() {
    ASolitaireModel testBad = new EuropeanSolitaireModel(50, 3);
  }

  /**
   * Test the third constructor for invalid inputs.
   */
  @Test(expected = IllegalArgumentException.class)
  public void testBadThirdConstructor2() {
    ASolitaireModel testBad = new EuropeanSolitaireModel(-1, 3);
  }

  /**
   * Test the third constructor for invalid inputs.
   */
  @Test(expected = IllegalArgumentException.class)
  public void testBadThirdConstructor3() {
    ASolitaireModel testBad = new EuropeanSolitaireModel(3, 50);
  }

  /**
   * Test the third constructor for invalid inputs.
   */
  @Test(expected = IllegalArgumentException.class)
  public void testBadThirdConstructor4() {
    ASolitaireModel testBad = new EuropeanSolitaireModel(3, -5);
  }

  /**
   * Test the fourth constructor for invalid inputs.
   */
  @Test(expected = IllegalArgumentException.class)
  public void testBadFourthConstructorSideLength() {
    ASolitaireModel testBad = new EuropeanSolitaireModel(4, 3, 3);
  }

  /**
   * Test the fourth constructor for invalid inputs.
   */
  @Test(expected = IllegalArgumentException.class)
  public void testBadFourthConstructorSideLength2() {
    ASolitaireModel testBad = new EuropeanSolitaireModel(-3, 3, 3);
  }

  /**
   * Test the fourth constructor for invalid inputs.
   */
  @Test(expected = IllegalArgumentException.class)
  public void testBadFourthConstructorPos() {
    ASolitaireModel testBad = new EuropeanSolitaireModel(3, 7, 3);
  }

  /**
   * Test the fourth constructor for invalid inputs.
   */
  @Test(expected = IllegalArgumentException.class)
  public void testBadFourthConstructorPos2() {
    ASolitaireModel testBad = new EuropeanSolitaireModel(3, -7, 3);
  }

  /**
   * Test the fourth constructor for invalid inputs.
   */
  @Test(expected = IllegalArgumentException.class)
  public void testBadFourthConstructorPos3() {
    ASolitaireModel testBad = new EuropeanSolitaireModel(3, 7, -3);
  }

  /**
   * Test the fourth constructor for invalid inputs.
   */
  @Test(expected = IllegalArgumentException.class)
  public void testBadFourthConstructorPos4() {
    ASolitaireModel testBad = new EuropeanSolitaireModel(3, 3, 7);
  }

  /**
   * Test getScore.
   */
  @Test
  public void testGetScore() {
    assertEquals(test1.getScore(), 36);
    test1.move(3, 1, 3, 3);
    test1.move(3, 4, 3, 2);
    test1.move(5, 3, 3, 3);
    assertEquals(test1.getScore(), 33);

    assertEquals(test2.getScore(), 128);
  }

  /**
   * Test getSlotAt with good inputs.
   */
  @Test
  public void testGetSlotAtGood() {
    assertEquals(test1.getSlotAt(0, 0), MarbleSolitaireModelState.SlotState.Invalid);
    assertEquals(test1.getSlotAt(3, 3), MarbleSolitaireModelState.SlotState.Empty);
    assertEquals(test1.getSlotAt(0, 3), MarbleSolitaireModelState.SlotState.Marble);
    assertEquals(test1.getSlotAt(3, 1), MarbleSolitaireModelState.SlotState.Marble);
    assertEquals(test1.getSlotAt(3, 2), MarbleSolitaireModelState.SlotState.Marble);

    test1.move(3, 1, 3, 3);
    assertEquals(test1.getSlotAt(3, 1), MarbleSolitaireModelState.SlotState.Empty);
    assertEquals(test1.getSlotAt(3, 3), MarbleSolitaireModelState.SlotState.Marble);
    assertEquals(test1.getSlotAt(3, 2), MarbleSolitaireModelState.SlotState.Empty);
  }

  /**
   * Test getSlotAt with invalid inputs.
   */
  @Test(expected = IllegalArgumentException.class)
  public void testGetSlotAtBad() {
    test1.getSlotAt(7,2);
  }

  /**
   * Test getSlotAt with invalid inputs.
   */
  @Test(expected = IllegalArgumentException.class)
  public void testGetSlotAtBad2() {
    test1.getSlotAt(-10,0);
  }

  /**
   * Test getSlotAt with invalid inputs.
   */
  @Test(expected = IllegalArgumentException.class)
  public void testGetSlotAtBad3() {
    test1.getSlotAt(3,-2);
  }

  /**
   * Test getSlotAt with invalid inputs.
   */
  @Test(expected = IllegalArgumentException.class)
  public void testGetSlotAtBad4() {
    test1.getSlotAt(3,200);
  }

  /**
   * Test getSlotAt with invalid inputs.
   */
  @Test(expected = IllegalArgumentException.class)
  public void testGetSlotAtBad5() {
    test4.getSlotAt(70,20);
  }

  /**
   * Test getBoardSize.
   */
  @Test
  public void testGetBoardSize() {
    assertEquals(test1.getBoardSize(), 7);
    assertEquals(test2.getBoardSize(), 13);
    assertEquals(new EuropeanSolitaireModel(9).getBoardSize(), 25);
  }

  /**
   * Test good moves.
   */
  @Test
  public void testGoodMove() {

    assertEquals(view1.toString(), "    O O O\n" +
            "  O O O O O\n" +
            "O O O O O O O\n" +
            "O O O _ O O O\n" +
            "O O O O O O O\n" +
            "  O O O O O\n" +
            "    O O O");

    test1.move(3, 1, 3, 3);
    test1.move(5, 2, 3, 2);
    test1.move(3, 3, 3, 1);
    test1.move(5, 3, 3, 3);

    assertEquals(view1.toString(), "    O O O\n" +
            "  O O O O O\n" +
            "O O O O O O O\n" +
            "O O _ O O O O\n" +
            "O O _ _ O O O\n" +
            "  O _ _ O O\n" +
            "    O O O");

    assertEquals(view2.toString(), "        O O O O O\n" +
            "      O O O O O O O\n" +
            "    O O O O O O O O O\n" +
            "  O O O O O O O O O O O\n" +
            "O O O O O O O O O O O O O\n" +
            "O O O O O O O O O O O O O\n" +
            "O O O O O O _ O O O O O O\n" +
            "O O O O O O O O O O O O O\n" +
            "O O O O O O O O O O O O O\n" +
            "  O O O O O O O O O O O\n" +
            "    O O O O O O O O O\n" +
            "      O O O O O O O\n" +
            "        O O O O O");

    test2.move(6, 4, 6, 6);
    test2.move(4, 5, 6, 5);
    test2.move(5, 7, 5, 5);
    test2.move(7, 7, 5, 7);

    assertEquals(view2.toString(), "        O O O O O\n" +
            "      O O O O O O O\n" +
            "    O O O O O O O O O\n" +
            "  O O O O O O O O O O O\n" +
            "O O O O O _ O O O O O O O\n" +
            "O O O O O O _ O O O O O O\n" +
            "O O O O _ O O _ O O O O O\n" +
            "O O O O O O O _ O O O O O\n" +
            "O O O O O O O O O O O O O\n" +
            "  O O O O O O O O O O O\n" +
            "    O O O O O O O O O\n" +
            "      O O O O O O O\n" +
            "        O O O O O");
  }

  /**
   * Test move with invalid inputs.
   */
  @Test(expected = IllegalArgumentException.class)
  public void testBadMoveInvalidPos1() {
    test1.move(-1, 0, 1, 0);
  }

  /**
   * Test move with invalid inputs.
   */
  @Test(expected = IllegalArgumentException.class)
  public void testBadMoveInvalidPos2() {
    test1.move(3, -1, 1, -1);
  }

  /**
   * Test move with invalid inputs.
   */
  @Test(expected = IllegalArgumentException.class)
  public void testBadMoveInvalidPos3() {
    test1.move(2, 0, 0, 0);
  }

  /**
   * Test move with invalid inputs.
   */
  @Test(expected = IllegalArgumentException.class)
  public void testBadMoveInvalidPos4() {
    test1.move(3, 4, 3, 6);
  }

  /**
   * Test move with invalid inputs.
   */
  @Test(expected = IllegalArgumentException.class)
  public void testBadMoveIllegalStartState() {
    test1.move(3, 3, 5, 3);
  }

  /**
   * Test move with invalid inputs.
   */
  @Test(expected = IllegalArgumentException.class)
  public void testBadMoveIllegalEndState() {
    test1.move(3, 2, 3, 4);
  }

  /**
   * Test move with invalid inputs.
   */
  @Test(expected = IllegalArgumentException.class)
  public void testBadMoveIllegalSpacing1() {
    test1.move(3, 0, 3, 3);
  }

  /**
   * Test move with invalid inputs.
   */
  @Test(expected = IllegalArgumentException.class)
  public void testBadMoveIllegalSpacing2() {
    test1.move(3, 2, 3, 3);
  }

  /**
   * Test move with invalid inputs.
   */
  @Test(expected = IllegalArgumentException.class)
  public void testBadMoveIllegalSpacing3() {
    test3.move(4, 4, 6, 6);
  }

  /**
   * Test move with invalid inputs.
   */
  @Test(expected = IllegalArgumentException.class)
  public void testBadMoveIllegalSpacing4() {
    test3.move(5, 0, 6, 6);
  }

  /**
   * Test move with invalid inputs.
   */
  @Test(expected = IllegalArgumentException.class)
  public void testBadMoveIllegalJump() {
    test1.move(3, 1, 3, 3);
    assertEquals(view1.toString(), "    O O O\n" +
            "  O O O O O\n" +
            "O O O O O O O\n" +
            "O _ _ O O O O\n" +
            "O O O O O O O\n" +
            "  O O O O O\n" +
            "    O O O"); //still ok here, the next move causes the failure
    test1.move(3, 0, 3, 2);
  }

  /**
   * Test move with invalid inputs.
   */
  @Test(expected = IllegalArgumentException.class)
  public void testBadMoveIllegalJump2() {
    test1.move(1, 3, 3, 3);
    assertEquals(view1.toString(), "    O O O\n" +
            "  O O _ O O\n" +
            "O O O _ O O O\n" +
            "O O O O O O O\n" +
            "O O O O O O O\n" +
            "  O O O O O\n" +
            "    O O O"); //still ok here, the next move causes the failure
    test1.move(0, 3, 2, 3);
  }

  /**
   * Test move with invalid inputs. Confirm that the board state does not change upon invalid move.
   */
  @Test
  public void testNotMoving() {
    try {
      assertEquals(view1.toString(), "    O O O\n" +
              "  O O O O O\n" +
              "O O O O O O O\n" +
              "O O O _ O O O\n" +
              "O O O O O O O\n" +
              "  O O O O O\n" +
              "    O O O");
      test1.move(3,3,3,3);
    } catch (IllegalArgumentException e) {
      assertEquals(view1.toString(), "    O O O\n" +
              "  O O O O O\n" +
              "O O O O O O O\n" +
              "O O O _ O O O\n" +
              "O O O O O O O\n" +
              "  O O O O O\n" +
              "    O O O");
    }
  }

  @Test
  public void testGameOver() {
    test3 = new EuropeanSolitaireModel(6, 2);
    view3 = new MarbleSolitaireTextView(test3);
    assertEquals(view3.toString(), "    O O O\n" +
            "  O O O O O\n" +
            "O O O O O O O\n" +
            "O O O O O O O\n" +
            "O O O O O O O\n" +
            "  O O O O O\n" +
            "    _ O O");
    test3.move(4, 2, 6, 2);
    test3.move(4, 4, 4, 2);
    test3.move(6, 4, 4, 4);
    test3.move(6, 3, 4, 3);
    test3.move(3, 2, 5, 2);
    test3.move(6, 2, 4, 2);
    test3.move(3, 0, 3, 2);
    test3.move(5, 1, 3, 1);
    test3.move(4, 3, 4, 1);
    test3.move(4, 0, 4, 2);
    test3.move(2, 1, 4, 1);
    test3.move(4, 1, 4, 3);
    test3.move(2, 3, 2, 1);
    test3.move(2, 0, 2, 2);
    test3.move(0, 3, 2, 3);
    test3.move(1, 1, 1, 3);
    test3.move(3, 2, 1, 2);
    test3.move(0, 2, 2, 2);
    test3.move(1, 4, 1, 2);
    test3.move(3, 4, 1, 4);
    test3.move(2, 6, 2, 4);
    test3.move(3, 6, 3, 4);
    test3.move(5, 5, 3, 5);
    test3.move(4, 3, 4, 5);
    test3.move(4, 6, 4, 4);
    test3.move(2, 3, 2, 5);
    test3.move(2, 5, 4, 5);
    test3.move(4, 5, 4, 3);
    test3.move(4, 3, 2, 3);
    test3.move(2, 2, 2, 4);
    test3.move(1, 5, 1, 3);
    test3.move(3, 4, 1, 4);
    test3.move(0, 4, 2, 4);
    test3.move(1, 2, 1, 4);
    assertFalse(test3.isGameOver());
    test3.move(1, 4, 3, 4);
    assertTrue(test3.isGameOver());
    assertEquals(view3.toString(), "    _ _ _\n" +
            "  _ _ _ _ _\n" +
            "_ _ _ _ _ _ _\n" +
            "_ _ _ _ O _ _\n" +
            "_ _ _ _ _ _ _\n" +
            "  _ _ _ _ _\n" +
            "    _ _ _");
  }


}
