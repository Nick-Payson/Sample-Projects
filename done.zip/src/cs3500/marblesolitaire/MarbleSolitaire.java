package cs3500.marblesolitaire;

import java.io.InputStreamReader;

import cs3500.marblesolitaire.controller.MarbleSolitaireController;
import cs3500.marblesolitaire.controller.MarbleSolitaireControllerImpl;
import cs3500.marblesolitaire.model.hw02.EnglishSolitaireModel;
import cs3500.marblesolitaire.model.hw04.ASolitaireModel;
import cs3500.marblesolitaire.view.ATextView;
import cs3500.marblesolitaire.view.MarbleSolitaireTextView;
import cs3500.marblesolitaire.view.TriangleSolitaireTextView;

/**
 * Play a game of marble solitaire from start to finish using command line arguments.
 * Initial arguments take the form of:
 * types: English , European , Triangular
 *             -size: OPTIONAL N , where N is a number, and it had better be positive.
 *             -hole: OPTIONAL R, C, where R and C are numbers, they had better be positive too.
 *             Format: Board Type -size N -hole R C
 */
public final class MarbleSolitaire {


  /**
   * Run the game with the given args, play from start to finish or quit and hope the user has fun.
   *     @param args the command line inputs to start a game.
   */
  public static void main(String[] args) {

    ASolitaireModel model = null;
    ATextView view = null;

    int size = -1;
    int row = -1;
    int col = -1;

    for (int i = 0; i < args.length; i++) {

      if (args[i].equalsIgnoreCase("-size")) {
        try {
          size = Integer.parseInt(args[i + 1]);
        } catch (Exception e) {
          System.out.println(e.getMessage());
          System.out.println("probably not an int after size, or nothing at all");
        }
      }

      if (args[i].equalsIgnoreCase("-hole")) {
        try {
          row = Integer.parseInt(args[i + 1]);
          col = Integer.parseInt(args[i + 1]);
        } catch (Exception e) {
          System.out.println(e.getMessage());
          System.out.println("probably not 2 ints after hole, or nothing at all");
        }
      }
    }

    if (args[0].equalsIgnoreCase("english")) {
      if (row == -1) {
        row = 3;
      }
      if (col == -1) {
        col = 3;
      }
      model = new EnglishSolitaireModel(Math.max(3, size), row, col);
      view = new MarbleSolitaireTextView(model);
    } else if (args[0].equalsIgnoreCase("european")) {

      if (row == -1) {
        row = 3;
      }
      if (col == -1) {
        col = 3;
      }
      model = new EnglishSolitaireModel(Math.max(3, size), row, col);
      view = new MarbleSolitaireTextView(model);
    }

    else if (args[0].equalsIgnoreCase("triangular")) {
      if (row == -1) {
        row = 0;
      }
      if (col == -1) {
        col = 0;
      }
      model = new EnglishSolitaireModel(Math.max(2, size), row, col);
      view = new TriangleSolitaireTextView(model);
    } else {
      throw new IllegalArgumentException(args[0] + "isn't a kind of board :(");
    }

    MarbleSolitaireController controller = new MarbleSolitaireControllerImpl(
            model, view, new InputStreamReader(System.in));
    controller.playGame();

  }
}