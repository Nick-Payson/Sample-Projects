package cs3500.marblesolitaire.model.hw04;

import java.util.ArrayList;

/**
 * Represent a triangle solitaire game, which has a triangular board.
 * It is important to note that this model does not use a rectangular coordinate system.
 * Positions on the triangle are indexed from (0,0) (the top point) to (n, 0) and (n, n),
 * the minimum and maximum positions on the bottom row. A nth row is indexed from (0,n) to (n,n).
 */
public class TriangleSolitaireModel extends ASolitaireModel {

  /**
   * Constructor - make a new TriangleSolitaireModel with the default settings.
   */
  public TriangleSolitaireModel() {
    super(5, 0, 0);
  }

  /**
   * Constructor - make a new TriangleSolitaireModel with the given size.
   *     @param dimensions the size for the board.
   *     @throws IllegalArgumentException if the size is < 1.
   */
  public TriangleSolitaireModel(int dimensions) throws IllegalArgumentException {
    super(dimensions, 0, 0);
  }

  /**
   * Constructor - make a new TriangleSolitaireModel with the given row/col inputs.
   *     @param row the row position for the empty slot.
   *     @param col the column position for the empty slot.
   *     @throws IllegalArgumentException if the empty slot position is invalid.
   */
  public TriangleSolitaireModel(int row, int col) throws IllegalArgumentException {
    super(5, row, col);
  }

  /**
   * Constructor - make a new TriangleSolitaireModel with the given inputs.
   *     @param dimensions the size for the board.
   *     @param row the row position for the empty slot.
   *     @param col the column position for the empty slot.
   *     @throws IllegalArgumentException if the size is not positive or the empty slot would
   *     be placed in an invalid location.
   */
  public TriangleSolitaireModel(int dimensions, int row, int col) throws IllegalArgumentException {
    super(dimensions, row, col);
  }

  /**
   * Set up the grid of SlotStates for the TriangleSolitaireModel.
   *     @param dimensions the length along the base.
   *     @param sRow the row position for the empty slot.
   *     @param sCol the column position for the empty slot.
   */
  public void generateGrid(int dimensions, int sRow, int sCol) {
    ArrayList<ArrayList<SlotState>> theList = new ArrayList<ArrayList<SlotState>>();

    for (int i = 0; i < dimensions; i ++) {
      ArrayList<SlotState> row = new ArrayList<SlotState>();
      for (int j = 0; j < dimensions; j++) {
        if (j <= i) {
          if (i == sRow && j == sCol) {
            row.add(SlotState.Empty);
          } else {
            row.add(SlotState.Marble);
          }
        } else {
          row.add(SlotState.Invalid);
        }

      }
      theList.add(row);
    }
    this.grid = theList;
  }

  /**
   * Return true if the move specified with the given coordinates is legal for this board.
   *     @param fromRow the initial row position.
   *     @param fromCol the initial column position.
   *     @param toRow the target row position.
   *     @param toCol the target column position.
   *     @return true/false if the move specified with the given coordinates is/isn't legal.
   */
  @Override
  protected boolean canMove(int fromRow, int fromCol, int toRow, int toCol) {

    if (! (isSlotOk(fromRow, fromCol) && isSlotOk(toRow, toCol))) {
      return false; //invalid positions
    }

    if (this.getSlotAt(fromRow, fromCol) != SlotState.Marble ||
            this.getSlotAt(toRow, toCol) != SlotState.Empty) {
      return false; // not picking up a marble, or landing on a non-empty square
    }

    int midRow = 0;
    int midCol = 0;

    if (fromRow == toRow && Math.abs(fromCol - toCol) == 2) {
      midRow = fromRow;
      midCol = (fromCol + toCol) / 2;

    } else if (fromCol == toCol && Math.abs(fromRow - toRow) == 2) {
      midRow = (fromRow + toRow) / 2;
      midCol = fromCol;

    } else if (fromRow - fromCol == toRow - toCol && Math.abs(fromRow - toRow) == 2) {
      midRow = (fromRow + toRow) / 2;
      midCol = (fromCol + toCol) / 2;

    } else { //not valid spacing
      return false;
    }

    return this.getSlotAt(midRow, midCol) == SlotState.Marble; //confirm jumping over marble
  }

  /**
   * Is the size acceptable for the TrianlgeSolitaireModel?.
   *     @param size the given size, a representation of the size of the board.
   *     @return true if the size is acceptable.
   */
  @Override
  protected boolean sizeOk(int size) {
    return size > 1;
  }

  /**
   * Is the game over?. Are there any moves left?.
   *     @return true/false if the game is/isn't over
   */
  @Override
  public boolean isGameOver() {

    for (int i = 0; i < super.dimensions; i++) {
      for (int j = 0; j <= i; j++) {
        if (this.canMove(i, j, i, j + 2) || this.canMove(i, j + 2 , i, j)) {
          return false; //horizontal moves
        }

        if (this.canMove(i, j, i + 2, j) || this.canMove(i + 2, j, i, j)) {
          return false; //left down or right up
        }

        if (this.canMove(i, j, i + 2, j + 2) ||
                this.canMove(i + 2, j + 2, i, j)) {
          return false; //right down or left up
        }

      }
    }

    return true;
  }

  /**
   * Compute and return the size of the board as an int.
   *     @return the size of the board as a int.
   */
  @Override
  public int getBoardSize() {
    return super.dimensions;
  }

  /**
   * Should the position described by row and col yield a Valid SlotState?.
   *     @param row the row coordinate for the position.
   *     @param col the column coordinate for the position.
   *     @return true if the position would be valid, false otherwise.
   */
  @Override
  protected boolean isPositionOk(int row, int col) {
    return col <= row && row < super.dimensions && col >= 0 && row >= 0;
  }

}
